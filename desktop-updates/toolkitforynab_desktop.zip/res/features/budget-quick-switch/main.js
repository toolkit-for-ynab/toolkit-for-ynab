'use strict';

(function poll() {
  if (typeof ynabToolKit !== 'undefined' && ynabToolKit.pageReady === true) {
    ynabToolKit.budgetQuickSwitch = function () {
      var applicationController = ynabToolKit.shared.containerLookup('controller:application');
      var userBudgetsController = ynabToolKit.shared.containerLookup('controller:users/budgets');

      function populateBudgetList() {
        var budgets = userBudgetsController.get('budgets');
        var currentBudgetId = applicationController.get('activeBudgetVersion').get('entityId');
        var $openBudgetListItem = $('.modal-select-budget').find('.modal-select-budget-open').parent();

        budgets.forEach(function (budget) {
          if (budget.get('budgetVersionId') === currentBudgetId) return;

          var budgetListItem = $('<li>').append($('<button>', { text: budget.get('budgetVersionName') }).prepend($('<i>', {
            class: 'flaticon stroke mail-1'
          }))).click(onBudgetClicked.bind(null, budget));

          $openBudgetListItem.after(budgetListItem);
        });
      }

      function onBudgetClicked(budget) {
        userBudgetsController.send('openBudget', budget.get('budgetVersionId'), budget.get('budgetVersionName'));
      }

      return {
        observe: function observe(changedNodes) {
          if (changedNodes.has('ynab-u modal-popup modal-select-budget ember-view modal-overlay active')) {
            populateBudgetList();
          }
        }
      };
    }();
  } else {
    setTimeout(poll, 250);
  }
})();