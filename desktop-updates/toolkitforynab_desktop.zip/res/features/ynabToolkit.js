/******/(function (modules) {
  // webpackBootstrap
  /******/ // The module cache
  /******/var installedModules = {};
  /******/
  /******/ // The require function
  /******/function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId]) {
      /******/return installedModules[moduleId].exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/i: moduleId,
      /******/l: false,
      /******/exports: {}
      /******/ };
    /******/
    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/
    /******/ // Flag the module as loaded
    /******/module.l = true;
    /******/
    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/
  }
  /******/
  /******/
  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;
  /******/
  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;
  /******/
  /******/ // identity function for calling harmony imports with the correct context
  /******/__webpack_require__.i = function (value) {
    return value;
  };
  /******/
  /******/ // define getter function for harmony exports
  /******/__webpack_require__.d = function (exports, name, getter) {
    /******/if (!__webpack_require__.o(exports, name)) {
      /******/Object.defineProperty(exports, name, {
        /******/configurable: false,
        /******/enumerable: true,
        /******/get: getter
        /******/ });
      /******/
    }
    /******/
  };
  /******/
  /******/ // getDefaultExport function for compatibility with non-harmony modules
  /******/__webpack_require__.n = function (module) {
    /******/var getter = module && module.__esModule ?
    /******/function getDefault() {
      return module['default'];
    } :
    /******/function getModuleExports() {
      return module;
    };
    /******/__webpack_require__.d(getter, 'a', getter);
    /******/return getter;
    /******/
  };
  /******/
  /******/ // Object.prototype.hasOwnProperty.call
  /******/__webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/
  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "";
  /******/
  /******/ // Load entry module and return exports
  /******/return __webpack_require__(__webpack_require__.s = 30);
  /******/
})(
/************************************************************************/
/******/[
/* 0 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_listeners__ = __webpack_require__(4);

  class Feature {
    constructor() {
      this.settings = {
        enabled: ynabToolKit.options[this.constructor.name]
      };
    }

    shouldInvoke() {
      // Default to no action. Unless you're implementing a CSS only feature,
      // you MUST override this to specify when your invoke() function should run!
      return false;
    }

    willInvoke() {
      /* stubbed optional hook for logic that must happen for a feature
      to work but doesn't need to happen on every invoke */
    }

    invoke() {
      throw Error(`Feature: ${this.constructor.name} does not implement required invoke() method.`);
    }

    injectCSS() {/* stubbed, default to no injected CSS */}

    observe() {/* stubbed listener function */}

    onRouteChanged() {/* stubbed listener function */}

    onBudgetChanged() {/* stubbed listener function */}

    applyListeners() {
      let observeListener = new __WEBPACK_IMPORTED_MODULE_0_core_listeners__["a" /* ObserveListener */]();
      observeListener.addFeature(this);

      let routeChangeListener = new __WEBPACK_IMPORTED_MODULE_0_core_listeners__["b" /* RouteChangeListener */]();
      routeChangeListener.addFeature(this);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = Feature;

  /***/
},
/* 1 */
/***/function (module, exports) {

  /*
  	MIT License http://www.opensource.org/licenses/mit-license.php
  	Author Tobias Koppers @sokra
  */
  // css base code, injected by the css-loader
  module.exports = function (useSourceMap) {
    var list = [];

    // return the list of modules as css string
    list.toString = function toString() {
      return this.map(function (item) {
        var content = cssWithMappingToString(item, useSourceMap);
        if (item[2]) {
          return "@media " + item[2] + "{" + content + "}";
        } else {
          return content;
        }
      }).join("");
    };

    // import a list of modules into the list
    list.i = function (modules, mediaQuery) {
      if (typeof modules === "string") modules = [[null, modules, ""]];
      var alreadyImportedModules = {};
      for (var i = 0; i < this.length; i++) {
        var id = this[i][0];
        if (typeof id === "number") alreadyImportedModules[id] = true;
      }
      for (i = 0; i < modules.length; i++) {
        var item = modules[i];
        // skip already imported module
        // this implementation is not 100% perfect for weird media query combinations
        //  when a module is imported multiple times with different media queries.
        //  I hope this will never occur (Hey this way we have smaller bundles)
        if (typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
          if (mediaQuery && !item[2]) {
            item[2] = mediaQuery;
          } else if (mediaQuery) {
            item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
          }
          list.push(item);
        }
      }
    };
    return list;
  };

  function cssWithMappingToString(item, useSourceMap) {
    var content = item[1] || '';
    var cssMapping = item[3];
    if (!cssMapping) {
      return content;
    }

    if (useSourceMap && typeof btoa === 'function') {
      var sourceMapping = toComment(cssMapping);
      var sourceURLs = cssMapping.sources.map(function (source) {
        return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */';
      });

      return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
    }

    return [content].join('\n');
  }

  // Adapted from convert-source-map (MIT)
  function toComment(sourceMap) {
    // eslint-disable-next-line no-undef
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
    var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;

    return '/*# ' + data + ' */';
  }

  /***/
},
/* 2 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony export (immutable) */
  __webpack_exports__["a"] = controllerLookup;
  /* harmony export (immutable) */__webpack_exports__["h"] = componentLookup;
  /* harmony export (immutable) */__webpack_exports__["c"] = getEmberView;
  /* harmony export (immutable) */__webpack_exports__["b"] = getCurrentRouteName;
  /* unused harmony export getCategoriesViewModel */
  /* harmony export (immutable) */__webpack_exports__["f"] = getAllBudgetMonthsViewModel;
  /* harmony export (immutable) */__webpack_exports__["g"] = getCurrentDate;
  /* harmony export (immutable) */__webpack_exports__["e"] = formatCurrency;
  /* harmony export (immutable) */__webpack_exports__["i"] = getToolkitStorageKey;
  /* harmony export (immutable) */__webpack_exports__["j"] = setToolkitStorageKey;
  /* harmony export (immutable) */__webpack_exports__["k"] = removeToolkitStorageKey;
  /* harmony export (immutable) */__webpack_exports__["d"] = transitionTo;
  const storageKeyPrefix = 'ynab-toolkit-';

  function controllerLookup(controllerName) {
    return containerLookup(`controller:${controllerName}`);
  }

  function componentLookup(componentName) {
    return containerLookup(`component:${componentName}`);
  }

  function getEmberView(viewId) {
    return getViewRegistry()[viewId];
  }

  function getCurrentRouteName() {
    let applicationController = controllerLookup('application');
    return applicationController.get('currentRouteName');
  }

  function getCategoriesViewModel() {
    return ynab.YNABSharedLib.getBudgetViewModel_CategoriesViewModel();
  }

  function getAllBudgetMonthsViewModel() {
    return ynab.YNABSharedLib.getBudgetViewModel_AllBudgetMonthsViewModel();
  }

  function getCurrentDate(format) {
    return ynabDate(format, false);
  }

  function formatCurrency(value) {
    let userCurrency = ynab.YNABSharedLib.currencyFormatter.getCurrency();
    let currencyFormatter = new ynab.formatters.CurrencyFormatter();
    currencyFormatter.initialize(userCurrency);
    userCurrency = currencyFormatter.getCurrency();

    let formattedCurrency = currencyFormatter.format(value).toString();
    if (userCurrency.symbol_first) {
      if (formattedCurrency.charAt(0) === '-') {
        formattedCurrency = `-${userCurrency.currency_symbol}${formattedCurrency.slice(1)}`;
      } else {
        formattedCurrency = `${userCurrency.currency_symbol}${formattedCurrency}`;
      }
    } else {
      formattedCurrency = `${formattedCurrency}${userCurrency.currency_symbol}`;
    }

    return formattedCurrency;
  }

  function getToolkitStorageKey(key, type) {
    let value = localStorage.getItem(storageKeyPrefix + key);

    switch (type) {
      case 'boolean':
        return value === 'true';
      case 'number':
        return Number(value);
      default:
        return value;
    }
  }

  function setToolkitStorageKey(key, value) {
    return localStorage.setItem(storageKeyPrefix + key, value);
  }

  function removeToolkitStorageKey(key) {
    return localStorage.removeItem(storageKeyPrefix + key);
  }

  function transitionTo() {
    const router = containerLookup('router:main');
    router.transitionTo(...arguments);
  }

  /* Private Functions */
  function getViewRegistry() {
    return Ember.Component.create().get('_viewRegistry');
  }

  function containerLookup(containerName) {
    const viewRegistry = getViewRegistry();
    const viewId = Ember.keys(viewRegistry)[0];
    const view = viewRegistry[viewId];

    let container;
    try {
      container = view.container.lookup(containerName);
    } catch (e) {
      container = view.container.factoryCache[containerName];
    }

    return container;
  }

  function ynabDate(format) {
    if (typeof format !== 'string') {
      return ynab.YNABSharedLib.dateFormatter.formatDate();
    }

    return ynab.YNABSharedLib.dateFormatter.formatDate(moment(), format);
  }

  /***/
},
/* 3 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0__accounts_additional_columns__ = __webpack_require__(9);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__accounts_adjustable_column_widths__ = __webpack_require__(11);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_2__accounts_auto_close_reconcile__ = __webpack_require__(12);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_3__accounts_change_enter_behavior__ = __webpack_require__(13);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_4__accounts_custom_flag_names__ = __webpack_require__(14);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_5__accounts_emphasized_outflows__ = __webpack_require__(15);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_6__accounts_row_height__ = __webpack_require__(16);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_7__accounts_show_category_balance__ = __webpack_require__(17);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_8__accounts_striped_rows__ = __webpack_require__(18);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_9__budget_display_goal_amount__ = __webpack_require__(19);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_10__budget_goal_warning_color__ = __webpack_require__(20);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_11__budget_remove_positive_highlight__ = __webpack_require__(21);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_12__budget_stealing_from_future__ = __webpack_require__(22);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_13__budget_target_balance_warning__ = __webpack_require__(23);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_14__general_accounts_display_density__ = __webpack_require__(24);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_15__general_colour_blind_mode__ = __webpack_require__(25);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_16__general_hide_age_of_money__ = __webpack_require__(26);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_17__general_hide_referral_banner__ = __webpack_require__(27);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_18__general_printing_improvements__ = __webpack_require__(28);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_19__general_square_negative_mode__ = __webpack_require__(29);
  /*
   ***********************************************************
   * Warning: This is a file generated by the build process. *
   *                                                         *
   * Any changes you make manually will be overwritten       *
   * the next time you run webpack!                          *
   ***********************************************************
  */

  const features = [__WEBPACK_IMPORTED_MODULE_0__accounts_additional_columns__["a" /* AdditionalColumns */], __WEBPACK_IMPORTED_MODULE_1__accounts_adjustable_column_widths__["a" /* AdjustableColumnWidths */], __WEBPACK_IMPORTED_MODULE_2__accounts_auto_close_reconcile__["a" /* AutoCloseReconcile */], __WEBPACK_IMPORTED_MODULE_3__accounts_change_enter_behavior__["a" /* ChangeEnterBehavior */], __WEBPACK_IMPORTED_MODULE_4__accounts_custom_flag_names__["a" /* CustomFlagNames */], __WEBPACK_IMPORTED_MODULE_5__accounts_emphasized_outflows__["a" /* AccountsEmphasizedOutflows */], __WEBPACK_IMPORTED_MODULE_6__accounts_row_height__["a" /* RowHeight */], __WEBPACK_IMPORTED_MODULE_7__accounts_show_category_balance__["a" /* ShowCategoryBalance */], __WEBPACK_IMPORTED_MODULE_8__accounts_striped_rows__["a" /* AccountsStripedRows */], __WEBPACK_IMPORTED_MODULE_9__budget_display_goal_amount__["a" /* DisplayTargetGoalAmount */], __WEBPACK_IMPORTED_MODULE_10__budget_goal_warning_color__["a" /* GoalWarningColor */], __WEBPACK_IMPORTED_MODULE_11__budget_remove_positive_highlight__["a" /* RemovePositiveHighlight */], __WEBPACK_IMPORTED_MODULE_12__budget_stealing_from_future__["a" /* StealingFromFuture */], __WEBPACK_IMPORTED_MODULE_13__budget_target_balance_warning__["a" /* TargetBalanceWarning */], __WEBPACK_IMPORTED_MODULE_14__general_accounts_display_density__["a" /* AccountsDisplayDensity */], __WEBPACK_IMPORTED_MODULE_15__general_colour_blind_mode__["a" /* ColourBlindMode */], __WEBPACK_IMPORTED_MODULE_16__general_hide_age_of_money__["a" /* HideAgeOfMoney */], __WEBPACK_IMPORTED_MODULE_17__general_hide_referral_banner__["a" /* HideReferralBanner */], __WEBPACK_IMPORTED_MODULE_18__general_printing_improvements__["a" /* PrintingImprovements */], __WEBPACK_IMPORTED_MODULE_19__general_square_negative_mode__["a" /* SquareNegativeMode */]];

  /* harmony default export */__webpack_exports__["a"] = features;

  /***/
},
/* 4 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0__observeListener__ = __webpack_require__(5);
  /* harmony reexport (binding) */__webpack_require__.d(__webpack_exports__, "a", function () {
    return __WEBPACK_IMPORTED_MODULE_0__observeListener__["a"];
  });
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__routeChangeListener__ = __webpack_require__(6);
  /* harmony reexport (binding) */__webpack_require__.d(__webpack_exports__, "b", function () {
    return __WEBPACK_IMPORTED_MODULE_1__routeChangeListener__["a"];
  });

  /***/
},
/* 5 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";

  let instance = null;

  class ObserveListener {
    constructor() {
      if (instance) {
        return instance;
      }

      this.features = [];

      let _MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
      let observer = new _MutationObserver(mutations => {
        this.changedNodes = new Set();

        mutations.forEach(mutation => {
          let newNodes = mutation.target;
          let $nodes = $(newNodes);

          $nodes.each((index, element) => {
            var nodeClass = $(element).attr('class');
            if (nodeClass) {
              this.changedNodes.add(nodeClass.replace(/^ember-view /, ''));
            }
          });
        });

        // Now we are ready to feed the change digest to the
        // automatically setup feedChanges file/function
        if (this.changedNodes.size > 0) {
          this.emitChanges();
        }
      });

      // This finally says 'Watch for changes' and only needs to be called the one time
      observer.observe($('.ember-view.layout')[0], {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['class']
      });

      return instance;
    }

    addFeature(feature) {
      if (this.features.indexOf(feature) === -1) {
        this.features.push(feature);
      }
    }

    emitChanges() {
      this.features.forEach(feature => {
        Ember.run.later(feature.observe.bind(feature, this.changedNodes), 0);
      });
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = ObserveListener;

  /***/
},
/* 6 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__ = __webpack_require__(2);

  let instance = null;

  class RouteChangeListener {
    constructor() {
      if (instance) {
        return instance;
      }

      let routeChangeListener = this;
      routeChangeListener.features = [];

      let applicationController = __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__["a" /* controllerLookup */])('application');
      applicationController.reopen({
        onRouteChanged: Ember.observer('currentRouteName', // this will handle accounts -> budget and vise versa
        'budgetVersionId', // this will handle changing budgets
        'selectedAccountId', // this will handle switching around accounts
        'monthString', // this will handle changing which month of a budget you're looking at
        (controller, changedProperty) => {
          if (changedProperty === 'budgetVersionId') {
            Ember.run.scheduleOnce('afterRender', controller, 'emitBudgetRouteChange');
          } else {
            Ember.run.scheduleOnce('afterRender', controller, 'emitSameBudgetRouteChange');
          }
        }),

        emitSameBudgetRouteChange: function () {
          let currentRoute = applicationController.get('currentRouteName');
          routeChangeListener.features.forEach(feature => {
            setTimeout(feature.onRouteChanged.bind(feature, currentRoute), 0);
          });
        },

        emitBudgetRouteChange: function () {
          let currentRoute = applicationController.get('currentRouteName');
          routeChangeListener.features.forEach(feature => {
            setTimeout(feature.onBudgetChanged.bind(feature, currentRoute), 0);
          });
        }
      });

      instance = this;
    }

    addFeature(feature) {
      if (this.features.indexOf(feature) === -1) {
        this.features.push(feature);
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = RouteChangeListener;

  /***/
},
/* 7 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";

  class AdditionalColumnStub {
    // Inserts the header for your additional column
    insertHeader() {}

    // Should remove all additional column related elements from the page
    cleanup() {}

    // Can return a promise, will get called during the normal willInvoke cycle
    // of a feature.
    willInvoke() {}

    // Should return a boolean that informs AdditionalColumns feature that it
    // is on a page that should recevie the new column.
    shouldInvoke() {}

    // Called when one of the grid rows is getting inserted into the dom but
    // before it actually makes it into the dom. This should be doing the grunt
    // of the work.
    willInsertColumn() {}

    // Called for all the rows that don't need the column data.
    willInsertDeadColumn() {}

    // this is really hacky but I'm not sure what else to do, most of these components
    // double render so the `willInsertElement` works for those but the add rows
    // and footer are weird. add-rows doesn't double render and will work every time
    // after the component has been cached but footer is _always_ a new component WutFace
    handleSingleRenderColumn() {}
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = AdditionalColumnStub;

  /***/
},
/* 8 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__ = __webpack_require__(2);

  class CheckNumbers {
    insertHeader() {
      if ($('.ynab-grid-header .ynab-grid-cell-toolkit-check-number').length) return;

      var $headerRow = $('.ynab-grid-header');
      var checkNumberHeader = $('.ynab-grid-cell-inflow', $headerRow).clone();
      checkNumberHeader.removeClass('ynab-grid-cell-inflow');
      checkNumberHeader.addClass('ynab-grid-cell-toolkit-check-number');
      checkNumberHeader.text('CHECK NUMBER').css('font-weight', 'normal');
      checkNumberHeader.insertAfter($('.ynab-grid-cell-memo', $headerRow));
      checkNumberHeader.click(event => {
        event.preventDefault();
        event.stopPropagation();
      });

      if ($('.ynab-grid-body .ynab-grid-body-row-top .ynab-grid-cell-toolkit-check-number').length) return;
      var $topRow = $('.ynab-grid-body-row-top');
      var topRowCheckNumber = $('.ynab-grid-cell-inflow', $topRow).clone();
      topRowCheckNumber.removeClass('ynab-grid-cell-inflow');
      topRowCheckNumber.addClass('ynab-grid-cell-toolkit-check-number');
      topRowCheckNumber.insertAfter($('.ynab-grid-cell-memo', $topRow));
    }

    cleanup() {
      $('.ynab-grid-cell-toolkit-check-number').remove();
    }

    // Don't need to do any pre-processing for check-numbers...carry on now.
    willInvoke() {
      return;
    }

    // Should return a boolean that informs AdditionalColumns feature that it
    // is on a page that should recevie the new column.
    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('account') !== -1;
    }

    // Called when one of the grid rows is getting inserted into the dom but
    // before it actually makes it into the dom. This should be doing the grunt
    // of the work.
    willInsertColumn() {
      const isAddRow = this.get('_debugContainerKey') === 'component:register/grid-add';
      const isEditRow = this.get('_debugContainerKey') === 'component:register/grid-edit';
      const isGridRow = this.get('_debugContainerKey') === 'component:register/grid-row';
      if (isAddRow || isEditRow) {
        const $editingRow = $(this.element);
        const editingTransaction = this.get('content');
        const $inputBox = $('<input placeholder="check number">').addClass('accounts-text-field').addClass('ynab-grid-cell-toolkit-check-number-input').blur(function () {
          editingTransaction.set('checkNumber', $(this).val());
        });

        $inputBox.val(editingTransaction.get('checkNumber'));
        $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-check-number"><div>').append($inputBox).insertAfter($('.ynab-grid-cell-memo', $editingRow));
      } else if (isGridRow) {
        // view only column
        const $currentRow = $(this.element);
        const checkNumberCell = $('.ynab-grid-cell-memo', $currentRow).clone();
        checkNumberCell.removeClass('ynab-grid-cell-memo');
        checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');

        const transaction = this.get('content');
        checkNumberCell.text(transaction.get('checkNumber') || '');
        checkNumberCell.insertAfter($('.ynab-grid-cell-memo', $currentRow));
      } else {
        // dead column
        const checkNumberCell = $('.ynab-grid-cell-memo', this.element).clone();
        checkNumberCell.removeClass('ynab-grid-cell-memo');
        checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');
        checkNumberCell.insertAfter($('.ynab-grid-cell-memo', this.element));
        checkNumberCell.empty();
      }
    }

    // this is really hacky but I'm not sure what else to do, most of these components
    // double render so the `willInsertElement` works for those but the add rows
    // and footer are weird. add-rows doesn't double render and will work every time
    // after the component has been cached but footer is _always_ a new component WutFace
    handleSingleRenderColumn($appendToRows, componentName) {
      if (componentName === 'register/grid-add') {
        const accountsController = ynabToolKit.shared.containerLookup('controller:accounts');
        const editingTransaction = accountsController.get('editingTransaction');
        const $inputBox = $('<input placeholder="check number">').addClass('accounts-text-field').addClass('ynab-grid-cell-toolkit-check-number-input').blur(function () {
          editingTransaction.set('checkNumber', $(this).val());
        });

        $inputBox.val(editingTransaction.get('checkNumber'));
        $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-check-number"><div>').append($inputBox).insertAfter($('.ynab-grid-cell-memo', $appendToRows));

        return;
      }

      $appendToRows.each((index, row) => {
        if ($('.ynab-grid-cell-toolkit-check-number', row).length === 0) {
          const checkNumberCell = $('.ynab-grid-cell-memo', row).clone();
          checkNumberCell.removeClass('ynab-grid-cell-memo');
          checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');
          checkNumberCell.insertAfter($('.ynab-grid-cell-memo', row));
          checkNumberCell.empty();
        }
      });
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = CheckNumbers;

  /***/
},
/* 9 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__additional_column_stub__ = __webpack_require__(7);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_2__running_balance__ = __webpack_require__(10);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_3__check_numbers__ = __webpack_require__(8);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_4_helpers_toolkit__ = __webpack_require__(2);

  class AdditionalColumns extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    constructor() {
      super();
      this.checkNumbers = ynabToolKit.options.CheckNumbers ? new __WEBPACK_IMPORTED_MODULE_3__check_numbers__["a" /* CheckNumbers */]() : new __WEBPACK_IMPORTED_MODULE_1__additional_column_stub__["a" /* AdditionalColumnStub */]();
      this.runningBalance = ynabToolKit.options.RunningBalance ? new __WEBPACK_IMPORTED_MODULE_2__running_balance__["a" /* RunningBalance */]() : new __WEBPACK_IMPORTED_MODULE_1__additional_column_stub__["a" /* AdditionalColumnStub */]();
    }

    injectCSS() {
      return __webpack_require__(48);
    }

    willInvoke() {
      // any of the components added here must be loaded when YNAB loads. if they
      // are not available in the cache, this feature will crash. move them to
      // invoke function if that is the case.
      this.attachWillInsertHandler('register/grid-sub');
      this.attachWillInsertHandler('register/grid-row');
      this.attachWillInsertHandler('register/grid-scheduled');
      this.attachWillInsertHandler('register/grid-scheduled-sub');
      this.attachWillInsertHandler('register/grid-actions');
      this.attachWillInsertHandler('register/grid-split');

      return Promise.all([this.checkNumbers.willInvoke(), this.runningBalance.willInvoke()]);
    }

    // we always want to invoke this feature if it's enabled because we want
    // to at least initialize running balance on all of the accounts
    shouldInvoke() {
      return this.runningBalance.shouldInvoke() || this.checkNumbers.shouldInvoke();
    }

    attachWillInsertHandler(componentName) {
      const _this = this;
      const GridComponent = __WEBPACK_IMPORTED_MODULE_4_helpers_toolkit__["h" /* componentLookup */](componentName);

      if (GridComponent.__toolkitInitialized) {
        return;
      }

      try {
        GridComponent.constructor.reopen({
          willInsertElement: function () {
            if (_this.checkNumbers.shouldInvoke()) {
              _this.checkNumbers.willInsertColumn.call(this);
            }

            if (_this.runningBalance.shouldInvoke()) {
              _this.runningBalance.willInsertColumn.call(this);
            }
          }
        });
      } catch (e) {
        GridComponent.reopen({
          willInsertElement: function () {
            if (_this.checkNumbers.shouldInvoke()) {
              _this.checkNumbers.willInsertColumn.call(this);
            }

            if (_this.runningBalance.shouldInvoke()) {
              _this.runningBalance.willInsertColumn.call(this);
            }
          }
        });
      }

      // this is really hacky but I'm not sure what else to do, most of these components
      // double render so the `willInsertElement` works for those but the add rows
      // and footer are weird. add-rows doesn't double render and will work every time
      // after the component has been cached but footer is _always_ a new component WutFace
      let $appendToRows;
      switch (componentName) {
        case 'register/grid-add':
          $appendToRows = $('.ynab-grid-add-rows .ynab-grid-body-row.is-editing');
          break;
        case 'register/grid-sub-edit':
          $appendToRows = $('.ynab-grid-body-sub.is-editing');
          break;
        case 'register/grid-footer':
          $appendToRows = $('.ynab-grid-body-row.ynab-grid-footer');
          break;
      }

      if ($appendToRows) {
        this.checkNumbers.handleSingleRenderColumn($appendToRows, componentName);
        this.runningBalance.handleSingleRenderColumn($appendToRows, componentName);
      }

      GridComponent.__toolkitInitialized = true;
    }

    invoke() {
      if (this.checkNumbers.shouldInvoke()) {
        this.checkNumbers.insertHeader();
      }

      if (this.runningBalance.shouldInvoke()) {
        this.runningBalance.insertHeader();
      }

      if ($('.ynab-grid-body-row.is-editing', '.ynab-grid-body').length) {
        this.attachWillInsertHandler('register/grid-edit');
      }

      if ($('.ynab-grid-add-rows', '.ynab-grid').length) {
        this.attachWillInsertHandler('register/grid-add');
      }

      if ($('.ynab-grid-body-split.is-editing', '.ynab-grid').length) {
        this.attachWillInsertHandler('register/grid-sub-edit');
      }

      if ($('.ynab-grid-body-row.ynab-grid-footer', '.ynab-grid').length) {
        this.attachWillInsertHandler('register/grid-footer');
      }

      ynabToolKit.invokeFeature('AdjustableColumnWidths');
    }

    observe(changedNodes) {
      if (!this.runningBalance.shouldInvoke()) {
        this.runningBalance.cleanup();
      }

      if (!this.checkNumbers.shouldInvoke()) {
        this.checkNumbers.cleanup();
      }

      if (!this.runningBalance.shouldInvoke() && !this.checkNumbers.shouldInvoke()) {
        return;
      }

      if (changedNodes.has('ynab-grid-body') || changedNodes.has('ynab-grid')) {
        this.invoke();
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = AdditionalColumns;

  /***/
},
/* 10 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__ = __webpack_require__(2);

  class RunningBalance {
    willInvoke() {
      return this.initializeRunningBalances();
    }

    shouldInvoke() {
      const applicationController = __WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__["a" /* controllerLookup */]('application');
      return applicationController.get('selectedAccountId') !== null;
    }

    cleanup() {
      $('.ynab-grid-cell-toolkit-running-balance').remove();
    }

    insertHeader() {
      if ($('.ynab-grid-header .ynab-grid-cell-toolkit-running-balance').length) return;

      var $headerRow = $('.ynab-grid-header');
      var runningBalanceHeader = $('.ynab-grid-cell-inflow', $headerRow).clone();
      runningBalanceHeader.removeClass('ynab-grid-cell-inflow');
      runningBalanceHeader.addClass('ynab-grid-cell-toolkit-running-balance');
      runningBalanceHeader.text('RUNNING BALANCE').css('font-weight', 'normal');
      runningBalanceHeader.insertAfter($('.ynab-grid-cell-inflow', $headerRow));
      runningBalanceHeader.click(event => {
        event.preventDefault();
        event.stopPropagation();
        $('.ynab-grid-cell-date', $headerRow).click();
      });

      if ($('.ynab-grid-body .ynab-grid-body-row-top .ynab-grid-cell-toolkit-running-balance').length) return;
      var $topRow = $('.ynab-grid-body-row-top');
      var topRowRunningBalance = $('.ynab-grid-cell-inflow', $topRow).clone();
      topRowRunningBalance.removeClass('ynab-grid-cell-inflow');
      topRowRunningBalance.addClass('ynab-grid-cell-toolkit-running-balance');
      topRowRunningBalance.insertAfter($('.ynab-grid-cell-inflow', $topRow));
    }

    handleSingleRenderColumn($appendToRows) {
      $appendToRows.each((index, row) => {
        if ($('.ynab-grid-cell-toolkit-running-balance', row).length === 0) {
          $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-running-balance">').insertAfter($('.ynab-grid-cell-inflow', row));
        }
      });
    }

    willInsertColumn() {
      const isSub = this.get('_debugContainerKey') === 'component:register/grid-sub';
      const isRow = this.get('_debugContainerKey') === 'component:register/grid-row';
      const isScheduled = this.get('_debugContainerKey') === 'component:register/grid-scheduled';
      const isRunningBalance = isSub || isRow || isScheduled;

      if (isRunningBalance) {
        const applicationController = __WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__["a" /* controllerLookup */]('application');
        const selectedAccountId = applicationController.get('selectedAccountId');
        if (!selectedAccountId) {
          return;
        }

        const $currentRow = $(this.element);
        const currentRowRunningBalance = $('.ynab-grid-cell-inflow', $currentRow).clone();
        currentRowRunningBalance.removeClass('ynab-grid-cell-inflow');
        currentRowRunningBalance.addClass('ynab-grid-cell-toolkit-running-balance');

        const transaction = this.get('content');

        let runningBalance = transaction.__ynabToolKitRunningBalance;
        if (typeof runningBalance === 'undefined') {
          calculateRunningBalance(selectedAccountId);
          runningBalance = transaction.__ynabToolKitRunningBalance;
        }

        const currencySpan = $('.user-data', currentRowRunningBalance);
        if (runningBalance < 0) {
          currencySpan.addClass('user-data currency negative');
        } else if (runningBalance > 0) {
          currencySpan.addClass('user-data currency positive');
        } else {
          currencySpan.addClass('user-data currency zero');
        }

        if (transaction.get('parentEntityId') !== null) {
          currencySpan.text('');
        } else {
          currencySpan.text(ynabToolKit.shared.formatCurrency(runningBalance));
        }

        currentRowRunningBalance.insertAfter($('.ynab-grid-cell-inflow', $currentRow));
      } else {
        if ($('.ynab-grid-cell-toolkit-running-balance', this.element).length === 0) {
          $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-running-balance">').insertAfter($('.ynab-grid-cell-inflow', this.element));
        }
      }
    }

    initializeRunningBalances() {
      return ynab.YNABSharedLib.defaultInstance.entityManager.accountsCollection.forEach(account => {
        return ynab.YNABSharedLib.defaultInstance.getBudgetViewModel_AccountTransactionsViewModel(account.entityId).then(accountViewModel => {
          calculateRunningBalance(account.entityId);

          // can you believe it? YNAB has this really interestingly name field
          // on visibleTransactionDisplayItems that sounds exactly like what I need
          // if something changes in that list, you tell me about it, and I'll update
          // the running balance for the account make sure our users always see the fancy
          accountViewModel.get('visibleTransactionDisplayItems').addObserver('anyItemChangedCounter', function () {
            calculateRunningBalance(account.entityId);
          });
        });
      });
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = RunningBalance;

  // Using ._result here bcause we can guarantee that we've already invoked the
  // getBudgetViewModel_AccountTransactionsViewModel() function when we initialized
  function calculateRunningBalance(accountId) {
    const accountsController = __WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__["a" /* controllerLookup */]('accounts');
    const accountViewModel = ynab.YNABSharedLib.defaultInstance.getBudgetViewModel_AccountTransactionsViewModel(accountId)._result;

    const transactions = accountViewModel.get('visibleTransactionDisplayItems');
    const sorted = transactions.slice().sort((a, b) => {
      var propA = a.get('date');
      var propB = b.get('date');

      if (propA instanceof ynab.utilities.DateWithoutTime) propA = propA.getUTCTime();
      if (propB instanceof ynab.utilities.DateWithoutTime) propB = propB.getUTCTime();

      var res = Ember.compare(propA, propB);

      if (res === 0) {
        res = Ember.compare(a.getAmount(), b.getAmount());
        if (accountsController.get('sortAscending')) {
          return res;
        }

        return -res;
      }

      return res;
    });

    let runningBalance = 0;
    sorted.forEach(transaction => {
      if (transaction.get('parentEntityId') !== null) {
        transaction.__ynabToolKitRunningBalance = runningBalance;
        return;
      }

      if (transaction.get('inflow')) {
        runningBalance += transaction.get('inflow');
      } else if (transaction.get('outflow')) {
        runningBalance -= transaction.get('outflow');
      }

      transaction.__ynabToolKitRunningBalance = runningBalance;
    });
  }

  /***/
},
/* 11 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  const RESIZABLES = ['ynab-grid-cell-date', 'ynab-grid-cell-accountName', 'ynab-grid-cell-payeeName', 'ynab-grid-cell-subCategoryName', 'ynab-grid-cell-memo', 'ynab-grid-cell-toolkit-check-number', 'ynab-grid-cell-outflow', 'ynab-grid-cell-inflow', 'ynab-grid-cell-toolkit-running-balance'];

  class AdjustableColumnWidths extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(49);
    }

    constructor() {
      super();
      this.elementWasDragged = false;
      this.isMouseDown = false;
      this.currentX = null;
    }

    shouldInvoke() {
      return __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */])().indexOf('account') !== -1;
    }

    onMouseMove(event) {
      if (!this.isMouseDown) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();

      Ember.run.debounce(this, () => {
        if (this.offTarget && !event.target.classList.contains('toolkit-draggable')) {
          return;
        }

        this.offTarget = false;
        const invertedDifference = this.currentX - event.clientX;
        const difference = invertedDifference * -1;

        const { isNeighborResizable, neighborCellName } = this.getNeighborOf(this.currentResizableClass);

        if (!isNeighborResizable) {
          return;
        }

        const $elementsOfTypeNeighbor = $(`.${neighborCellName}`);
        const neighborWidth = $elementsOfTypeNeighbor.width();
        const newNeighborWidth = neighborWidth - difference;

        const $elementsOfTypeCurrentResizable = $(`.${this.currentResizableClass}`);
        const currentResizableWidth = $elementsOfTypeCurrentResizable.width();
        const newCurrentResizableWidth = currentResizableWidth + difference;

        if (newNeighborWidth < 50 || newCurrentResizableWidth < 50) {
          this.offTarget = true;
          return;
        }

        this.currentX = event.clientX;
        $elementsOfTypeCurrentResizable.width(newCurrentResizableWidth);
        __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["j" /* setToolkitStorageKey */])(`column-width-${this.currentResizableClass}`, newCurrentResizableWidth);

        $elementsOfTypeNeighbor.width(newNeighborWidth);
        __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["j" /* setToolkitStorageKey */])(`column-width-${neighborCellName}`, newNeighborWidth);
      }, 100);
    }

    onMouseUp() {
      $('body').off('mousemove', this.bindOnMouseMove);
      $('body').off('mouseup', this.bindOnMouseUp);

      if (this.isMouseDown) {
        this.isMouseDown = false;
        this.elementWasDragged = true;
      }
    }

    getNeighborOf(neighborOf) {
      const $rightNeighbor = $(`.${neighborOf}`, '.ynab-grid-header').next();

      if (!$rightNeighbor.length) {
        return { isNeighborResizable: false };
      }

      const neighborCellName = $rightNeighbor.prop('class').match(/ynab-grid-cell.*/)[0];
      return {
        neighborCellName,
        isNeighborResizable: RESIZABLES.some(className => className === neighborCellName)
      };
    }

    resetWidths() {
      RESIZABLES.forEach(resizableClass => {
        $(`.${resizableClass}`).width('');
        __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["k" /* removeToolkitStorageKey */])(`column-width-${resizableClass}`);
      });
    }

    invoke() {
      if (!$('.toolkit-reset-widths').length) {
        $('<button class="toolkit-reset-widths button">Reset Column Widths</button>').click(this.resetWidths).insertAfter($('.accounts-toolbar-all-dates', '.accounts-toolbar-right'));
      }

      RESIZABLES.forEach(resizableClass => {
        const width = __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["i" /* getToolkitStorageKey */])(`column-width-${resizableClass}`, 'number');
        if (width) {
          $(`.${resizableClass}`).width(width);
        }

        if (!this.getNeighborOf(resizableClass).isNeighborResizable) {
          return;
        }

        if ($(`.${resizableClass} .toolkit-draggable`, '.ynab-grid-header').length) {
          return;
        }

        $(`.${resizableClass}`, '.ynab-grid-header').click(event => {
          if (this.elementWasDragged) {
            event.preventDefault();
            event.stopPropagation();
            this.elementWasDragged = false;
          }
        }).css({ position: 'relative' }).append($('<div class="toolkit-draggable"></div>').click(event => event.stopPropagation()).mousedown(event => {
          this.isMouseDown = true;
          this.currentX = event.clientX;
          this.currentResizableClass = resizableClass;

          this.bindOnMouseMove = this.onMouseMove.bind(this);
          this.bindOnMouseUp = this.onMouseUp.bind(this);
          $('body').on('mousemove', this.bindOnMouseMove);
          $('body').on('mouseup', this.bindOnMouseUp);
        }));
      });
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) {
        return;
      }
      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = AdjustableColumnWidths;

  /***/
},
/* 12 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  class AutoCloseReconcile extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    observe(changedNodes) {
      if (changedNodes.has('modal-account-reconcile-current') && changedNodes.has('flaticon stroke checkmark-2')) {
        Ember.run.later(() => {
          const applicationController = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["a" /* controllerLookup */]('application');
          applicationController.send('closeModal');
        }, 1500);
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = AutoCloseReconcile;

  /***/
},
/* 13 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  class ChangeEnterBehavior extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('account') !== -1 && $('.ynab-grid-body-row.is-adding').length;
    }

    invoke() {
      const $addRow = $('.ynab-grid-body-row.is-adding');
      const $memoInput = $('.ynab-grid-cell-memo input', $addRow);
      const $outflowInput = $('.ynab-grid-cell-outflow input', $addRow);
      const $inflowInput = $('.ynab-grid-cell-inflow input', $addRow);

      if (!$memoInput[0].getAttribute('data-toolkit-save-behavior')) {
        $memoInput[0].setAttribute('data-toolkit-save-behavior', true);
        $memoInput.keydown(this.applyNewEnterBehavior);
      }

      if (!$outflowInput[0].getAttribute('data-toolkit-save-behavior')) {
        $outflowInput[0].setAttribute('data-toolkit-save-behavior', true);
        $outflowInput.keydown(this.applyNewEnterBehavior);
      }

      if (!$inflowInput[0].getAttribute('data-toolkit-save-behavior')) {
        $inflowInput[0].setAttribute('data-toolkit-save-behavior', true);
        $inflowInput.keydown(this.applyNewEnterBehavior);
      }
    }

    applyNewEnterBehavior(event) {
      if (event.keyCode === 13) {
        event.preventDefault();
        event.stopPropagation();

        const $saveButton = $('.button.button-primary:not(.button-another)');
        $saveButton.click();
      }
    }

    observe(changedNodes) {
      if (!changedNodes.has('ynab-grid-body')) return;

      if (this.shouldInvoke()) {
        this.invoke();
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = ChangeEnterBehavior;

  /***/
},
/* 14 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  let flags;
  let redFlagLabel;
  let blueFlagLabel;
  let orangeFlagLabel;
  let yellowFlagLabel;
  let greenFlagLabel;
  let purpleFlagLabel;

  class CustomFlagNames extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    constructor() {
      super();
      if (!__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["i" /* getToolkitStorageKey */]('flags')) {
        this.storeDefaultFlags();
      }
      if (typeof flags === 'undefined') {
        flags = JSON.parse(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["i" /* getToolkitStorageKey */]('flags'));
        this.updateFlagLabels();
      }
    }

    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('account') !== -1;
    }

    invoke() {
      $('.ynab-grid-cell-flag .ynab-flag-red').parent().attr('title', redFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-blue').parent().attr('title', blueFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-orange').parent().attr('title', orangeFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-yellow').parent().attr('title', yellowFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-green').parent().attr('title', greenFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-purple').parent().attr('title', purpleFlagLabel);
    }

    observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('layout user-logged-in') || changedNodes.has('ynab-grid-body')) {
        this.invoke();
      }

      if (changedNodes.has('ynab-u modal-popup modal-account-flags ember-view modal-overlay active')) {
        $('.ynab-flag-red .label, .ynab-flag-red .label-bg').text(redFlagLabel);
        $('.ynab-flag-blue .label, .ynab-flag-blue .label-bg').text(blueFlagLabel);
        $('.ynab-flag-orange .label, .ynab-flag-orange .label-bg').text(orangeFlagLabel);
        $('.ynab-flag-yellow .label, .ynab-flag-yellow .label-bg').text(yellowFlagLabel);
        $('.ynab-flag-green .label, .ynab-flag-green .label-bg').text(greenFlagLabel);
        $('.ynab-flag-purple .label, .ynab-flag-purple .label-bg').text(purpleFlagLabel);

        $('.modal-account-flags .modal').css({ height: '22em' }).append($('<div>', { id: 'account-flags-actions' }).css({ padding: '0 .3em' }).append($('<button>', { id: 'flags-edit', class: 'button button-primary' }).append('Edit ').append($('<i>', { class: 'flaticon stroke compose-3' }))));

        this.addEventListeners();
      }
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;

      this.invoke();
    }

    addEventListeners() {
      let $this = this;
      $('#flags-edit').click(function () {
        $('.modal-account-flags .modal-list').empty();

        for (let key in flags) {
          let flag = flags[key];

          $('.modal-account-flags .modal-list').append($('<li>').append($('<input>', { id: key, type: 'text', class: 'flag-input', value: flag.label, placeholder: flag.label }).css({ color: '#fff', fill: flag.color, 'background-color': flag.color, height: 30, padding: '0 .7em', 'margin-bottom': '.3em', border: 'none' })));
        }

        $('#account-flags-actions').empty();

        $('#account-flags-actions').append($('<button>', { id: 'flags-close', class: 'button button-primary' }).append('Ok ').append($('<i>', { class: 'flaticon stroke checkmark-2' })));

        $('input.flag-input').focus(function () {
          $(this).css({
            color: '#000'
          });
        });

        $('input.flag-input').blur(function () {
          $(this).css({
            color: '#fff'
          });
          $this.saveFlag($(this));
        });

        $('#flags-close').click(function () {
          $('.modal-overlay').click();
        });
      });
    }

    saveFlag(flag) {
      if (flag.attr('placeholder') !== flag.val()) {
        let key = flag.attr('id');

        flags[key].label = flag.val();
        __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["j" /* setToolkitStorageKey */]('flags', JSON.stringify(flags));

        this.updateFlagLabels();
        this.invoke();
      }
    }

    updateFlagLabels() {
      redFlagLabel = flags.red.label;
      blueFlagLabel = flags.blue.label;
      orangeFlagLabel = flags.orange.label;
      yellowFlagLabel = flags.yellow.label;
      greenFlagLabel = flags.green.label;
      purpleFlagLabel = flags.purple.label;
    }

    storeDefaultFlags() {
      const flagsJSON = {
        red: {
          label: 'Red',
          color: '#d43d2e'
        },
        orange: {
          label: 'Orange',
          color: '#ff7b00'
        },
        yellow: {
          label: 'Yellow',
          color: '#f8e136'
        },
        green: {
          label: 'Green',
          color: '#9ac234'
        },
        blue: {
          label: 'Blue',
          color: '#0082cb'
        },
        purple: {
          label: 'Purple',
          color: '#9384b7'
        }
      };
      __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["j" /* setToolkitStorageKey */]('flags', JSON.stringify(flagsJSON));
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = CustomFlagNames;

  /***/
},
/* 15 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class AccountsEmphasizedOutflows extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(50);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = AccountsEmphasizedOutflows;

  /***/
},
/* 16 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  const compactHeight = 27;
  const slimHeight = 22;

  class RowHeight extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      let css = __webpack_require__(52);

      if (this.settings.enabled === '1') {
        css += __webpack_require__(51);
      } else if (this.settings.enabled === '2') {
        css += __webpack_require__(53);
      }

      return css;
    }

    invoke() {
      // If the activity-transaction-link feature is not active we don't want to adjust the
      // record height because doing so causes scrolling to be jumpier than usual. If the
      // activity-transaction-link feature is active we do need to set the record height
      // because it uses the value to scroll the "selected transaction" to the top of the
      // register.
      if (ynabToolKit.options.activityTransactionLink) {
        let ynabGridContainer = __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["c" /* getEmberView */])($('.ynab-grid-container').attr('id'));

        // Will be undefined when YNAB is loaded going directly to the budget screen.
        if (typeof ynabGridContainer !== 'undefined') {
          let recordHeight = ynabGridContainer.get('recordHeight');

          // The second check is to minimize the times that recordHeight is changed because
          // each time it's changed YNAB reacts to it and that contributes to the scrolling
          // jumpyness.
          if (ynabToolKit.options.accountsRowHeight === '1' && recordHeight !== compactHeight) {
            ynabGridContainer.set('recordHeight', compactHeight);
          } else if (ynabToolKit.options.accountsRowHeight === '2' && recordHeight !== slimHeight) {
            ynabGridContainer.set('recordHeight', slimHeight);
          }
        }

        // Add our class so our CSS can take effect.
        $('.ynab-grid-body-row-top > .ynab-grid-cell').addClass('toolkit-ynab-grid-cell');
      }
    }

    // We always want to invoke so we can run on page load and such.
    shouldInvoke() {
      return true;
    }

    observe(changedNodes) {
      if (changedNodes.has('ynab-grid-body')) {
        this.invoke();
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = RowHeight;

  /***/
},
/* 17 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  class ShowCategoryBalance extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('account') !== -1;
    }

    invoke() {
      __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["f" /* getAllBudgetMonthsViewModel */]().then(allBudgetMonthsViewModel => {
        let subCategoryCalculations = allBudgetMonthsViewModel.get('monthlySubCategoryBudgetCalculationsCollection');
        let categoryLookupPrefix = `mcbc/${__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["g" /* getCurrentDate */]('YYYY-MM')}`;

        let GridSubComponent = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["h" /* componentLookup */]('register/grid-sub');
        GridSubComponent.constructor.reopen({
          didRender: function () {
            didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });

        let GridRowComponent = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["h" /* componentLookup */]('register/grid-row');
        GridRowComponent.constructor.reopen({
          didRender: function () {
            didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });

        let GridScheduledComponent = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["h" /* componentLookup */]('register/grid-scheduled');
        GridScheduledComponent.constructor.reopen({
          didRender: function () {
            didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });
      });
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;

      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = ShowCategoryBalance;

  function didRender(subCategoryCalculations, categoryLookupPrefix) {
    let element = this.get('element');
    let subCategoryId = this.get('content.subCategoryId');
    let budgetData = subCategoryCalculations.findItemByEntityId(`${categoryLookupPrefix}/${subCategoryId}`);

    // if there's no budget data (could be an income/credit category) skip it.
    if (!budgetData) return;

    let title = $('.ynab-grid-cell-subCategoryName', element).attr('title');
    let newTitle = `${title} (Balance: ${__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["e" /* formatCurrency */](budgetData.get('balance'))})`;
    $('.ynab-grid-cell-subCategoryName', element).attr('title', newTitle);
  }

  /***/
},
/* 18 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class AccountsStripedRows extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(54);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = AccountsStripedRows;

  /***/
},
/* 19 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  class DisplayTargetGoalAmount extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('budget') !== -1 && this.settings.enabled !== '0';
    }

    invoke() {
      $('.budget-table-header .budget-table-cell-name').css('position', 'relative');
      $('.budget-table-row.is-sub-category li.budget-table-cell-name').css('position', 'relative');

      $('.budget-table-header .budget-table-cell-name').append($('<div>', { class: 'budget-table-cell-goal' }).css({ position: 'absolute', right: 0, top: '6px' }).append('GOAL'));

      $('.budget-table-row.is-sub-category li.budget-table-cell-name').append($('<div>', { class: 'budget-table-cell-goal currency' }).css({
        background: '-webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 10%,rgba(255,255,255,1) 100%)', position: 'absolute', 'font-size': '80%', 'padding-left': '.75em', 'padding-right': '1px', 'line-height': '2.55em'
      }));

      $('.budget-table-row.is-sub-category').each((index, element) => {
        const emberId = element.id;
        const viewData = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["c" /* getEmberView */](emberId).data;
        const { subCategory } = viewData;
        const { monthlySubCategoryBudget } = viewData;
        const { monthlySubCategoryBudgetCalculation } = viewData;
        const goalType = subCategory.get('goalType');
        const monthlyFunding = subCategory.get('monthlyFunding');
        const targetBalance = subCategory.get('targetBalance');
        const targetBalanceDate = monthlySubCategoryBudgetCalculation.get('goalTarget');
        const budgetedAmount = monthlySubCategoryBudget.get('budgeted');
        if (goalType === 'MF') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["e" /* formatCurrency */](monthlyFunding));
          if (budgetedAmount > monthlyFunding && this.settings.enabled === '1') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else if (budgetedAmount >= monthlyFunding) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          }
        } else if (goalType === 'TB') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["e" /* formatCurrency */](targetBalance));
          if (budgetedAmount > targetBalance && this.settings.enabled === '1') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else if (budgetedAmount >= targetBalance) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          }
        } else if (goalType === 'TBD') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["e" /* formatCurrency */](targetBalanceDate));
          if (budgetedAmount > targetBalanceDate && this.settings.enabled === '1') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else if (budgetedAmount >= targetBalanceDate) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          }
        }
      });
    }

    observe(changedNodes) {
      if (!this.shouldInvoke()) return;
      if (changedNodes.has('budget-table-cell-budgeted')) {
        $('.budget-table-cell-goal').remove();
        this.invoke();
      }
      if (changedNodes.has('ynab-checkbox-button is-checked') || !changedNodes.has('ynab-checkbox-button is-checked')) {
        $('.budget-table-row.is-sub-category li.budget-table-cell-name .budget-table-cell-goal').css({
          background: '-webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 10%,rgba(255,255,255,1) 100%)' });
        $('.budget-table-row.is-checked li.budget-table-cell-name .budget-table-cell-goal').css({ background: '#005a6e' });
      }
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = DisplayTargetGoalAmount;

  /***/
},
/* 20 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class GoalWarningColor extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(55);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = GoalWarningColor;

  /***/
},
/* 21 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class RemovePositiveHighlight extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(56);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = RemovePositiveHighlight;

  /***/
},
/* 22 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  // TODO: move income-from-last-month to the new framework and just export this
  // variable from that feature
  const INCOME_FROM_LAST_MONTH_CLASSNAME = 'income-from-last-month';

  class StealingFromFuture extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(57);
    }

    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('budget') !== -1;
    }

    isMonthABeforeB(a, b) {
      if (b === null) return true;

      const [yearA, monthA] = a.split('-').map(val => parseInt(val));
      const [yearB, monthB] = b.split('-').map(val => parseInt(val));
      if (yearA >= yearB && monthA >= monthB) {
        return false;
      }

      return true;
    }

    onAvailableToBudgetChange(budgetViewModel) {
      let earliestEntityDate = null;
      let earliestNegativeMonth = null;
      let earliestNegativeMonthCalculation = null;
      budgetViewModel.get('allBudgetMonthsViewModel.monthlyBudgetCalculationsCollection').forEach(monthCalculation => {
        if (this.isMonthEntityIdFuture(monthCalculation.get('entityId'))) {
          const entityDate = monthCalculation.get('entityId').match(/mbc\/(.*)\/.*/)[1];
          const entityMonth = entityDate.split('-').map(val => parseInt(val))[1];

          if (monthCalculation.get('availableToBudget') < 0 && this.isMonthABeforeB(entityDate, earliestEntityDate)) {
            earliestEntityDate = entityDate;
            earliestNegativeMonth = entityMonth;
            earliestNegativeMonthCalculation = monthCalculation;
          }
        }
      });

      // there's no easy class name on the thing we want to highlight so
      // we have to just select the specific row. if the user has the income
      // from last month feature on and it has already invoked, then the row
      // we want is number 4, else 3.
      let futureBudgetRow = 3;
      if (ynabToolKit.options.incomeFromLastMonth !== '0') {
        if ($(`.budget-header-totals-details-values .${INCOME_FROM_LAST_MONTH_CLASSNAME}`).length) {
          futureBudgetRow = 4;
        }
      }

      const value = $('.budget-header-totals-details-values .budget-header-totals-cell-value').eq(futureBudgetRow);
      const name = $('.budget-header-totals-details-names .budget-header-totals-cell-name').eq(futureBudgetRow);

      // no negative months! good job team!
      if (earliestNegativeMonth === null) {
        value.removeClass('ynabtk-stealing-from-next-month');
        name.removeClass('ynabtk-stealing-from-next-month');
        $('#ynabtk-stealing-amount', name).remove();
        return;
      }

      value.addClass('ynabtk-stealing-from-next-month');
      name.addClass('ynabtk-stealing-from-next-month');

      const availableToBudget = earliestNegativeMonthCalculation.getAvailableToBudget();
      $('#ynabtk-stealing-amount', name).remove();
      name.append('<span id="ynabtk-stealing-amount"> (' + '<strong>' + `${ynab.formatCurrency(availableToBudget)} in ` + `<a class="ynabtk-month-link">${ynabToolKit.shared.monthsFull[earliestNegativeMonth - 1]}</a>` + '</strong>' + ')</span>');

      $('.ynabtk-month-link', name).click(event => {
        event.preventDefault();
        const applicationController = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["a" /* controllerLookup */]('application');
        const budgetVersionId = applicationController.get('budgetVersionId');
        __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["d" /* transitionTo */]('budget.select', budgetVersionId, earliestEntityDate.replace('-', ''));
      });
    }

    isMonthEntityIdFuture(entityId) {
      const currentYear = parseInt(moment().format('YYYY'));
      const currentMonth = parseInt(moment().format('MM'));
      const entityDate = entityId.match(/mbc\/(.*)\/.*/)[1];
      const [entityYear, entityMonth] = entityDate.split('-').map(val => parseInt(val));
      if (entityYear >= currentYear && entityMonth > currentMonth) {
        return true;
      }

      return false;
    }

    invoke() {
      let budgetController = ynabToolKit.shared.containerLookup('controller:budget');
      let budgetViewModel = budgetController.get('budgetViewModel');
      if (budgetViewModel) {
        budgetViewModel.get('allBudgetMonthsViewModel.monthlyBudgetCalculationsCollection').forEach(month => {
          month.addObserver('availableToBudget', this.onAvailableToBudgetChange.bind(this, budgetViewModel));
        });

        this.onAvailableToBudgetChange(budgetViewModel);
      }
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = StealingFromFuture;

  /***/
},
/* 23 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(2);

  class TargetBalanceWarning extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    constructor() {
      super();
    }

    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('budget') !== -1;
    }

    invoke() {
      $('.budget-table-row.is-sub-category').each((index, element) => {
        const emberId = element.id;
        const viewData = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["c" /* getEmberView */](emberId).data;
        const { subCategory } = viewData;

        if (subCategory.get('goalType') === ynab.constants.SubCategoryGoalType.TargetBalance) {
          const available = viewData.get('available');
          const targetBalance = subCategory.get('targetBalance');
          const currencyElement = $('.budget-table-cell-available .user-data.currency', element);

          if (available < targetBalance && !currencyElement.hasClass('cautious')) {
            if (currencyElement.hasClass('positive')) {
              currencyElement.removeClass('positive');
            }

            currencyElement.addClass('cautious');
          }
        }
      });
    }

    observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('budget-table-cell-available-div user-data')) {
        this.invoke();
      }
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = TargetBalanceWarning;

  /***/
},
/* 24 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class AccountsDisplayDensity extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(58);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(59);
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = AccountsDisplayDensity;

  /***/
},
/* 25 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class ColourBlindMode extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(60);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = ColourBlindMode;

  /***/
},
/* 26 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class HideAgeOfMoney extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(61);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = HideAgeOfMoney;

  /***/
},
/* 27 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class HideReferralBanner extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(62);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = HideReferralBanner;

  /***/
},
/* 28 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class PrintingImprovements extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(63);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = PrintingImprovements;

  /***/
},
/* 29 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class SquareNegativeMode extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* Feature */] {
    injectCSS() {
      return __webpack_require__(64);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = SquareNegativeMode;

  /***/
},
/* 30 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";

  Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_features__ = __webpack_require__(3);

  const featureInstances = __WEBPACK_IMPORTED_MODULE_0_features__["a" /* default */].map(Feature => new Feature());

  // This poll() function will only need to run until we find that the DOM is ready
  (function poll() {
    if (typeof Em !== 'undefined' && typeof Ember !== 'undefined' && typeof $ !== 'undefined' && $('.ember-view.layout').length && typeof ynabToolKit !== 'undefined') {
      // Gather any desired global CSS from features
      let globalCSS = '';

      featureInstances.forEach(feature => {
        if (feature.settings.enabled && feature.injectCSS()) {
          globalCSS += `/* == Injected CSS from feature: ${feature.constructor.name} == */\n\n${feature.injectCSS()}\n`;
        }
      });

      ynabToolKit.invokeFeature = featureName => {
        featureInstances.forEach(feature => {
          if (feature.constructor.name === featureName && feature.shouldInvoke()) {
            feature.invoke();
          }
        });
      };

      // Inject it into the head so it's left alone
      $('head').append($('<style>', { id: 'toolkit-injected-styles', type: 'text/css' }).text(globalCSS));

      // Hook up listeners and then invoke any features that are ready to go.
      featureInstances.forEach(feature => {
        if (feature.settings.enabled) {
          feature.applyListeners();

          const willInvokeRetValue = feature.willInvoke();

          if (willInvokeRetValue && typeof willInvokeRetValue.then === 'function') {
            willInvokeRetValue.then(() => {
              if (feature.shouldInvoke()) {
                feature.invoke();
              }
            });
          } else {
            if (feature.shouldInvoke()) {
              feature.invoke();
            }
          }
        }
      });
    } else {
      setTimeout(poll, 250);
    }
  })();

  /***/
},
/* 31 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-cell-toolkit-running-balance {\n\ttext-align: right;\n\twidth: 10%;\n}\n\n.ynab-grid-cell-toolkit-running-balance span.negative {\n\tcolor: #d33c2d;\n\tfont-weight: bold;\n}\n\n.ynab-grid-cell-toolkit-check-number {\n\ttext-align: right;\n\twidth: 10%;\n}\n", ""]);

  // exports


  /***/
},
/* 32 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".toolkit-draggable {\n  display: inline-block;\n  right: 0;\n  position: absolute;\n  background: transparent;\n  width: 4px;\n  height: inherit;\n  cursor: col-resize;\n}\n\n.toolkit-reset-widths {\n  padding-top: .4em;\n}\n", ""]);

  // exports


  /***/
},
/* 33 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-cell-outflow .currency::before {\n\tcontent: \"(\";\n}\n\n.ynab-grid-cell-outflow .currency::after {\n\tcontent: \")\";\n}\n\n.ynab-grid-cell-outflow .currency {\n\tcolor: #c00;\n}\n\n.ynab-grid-body-row.is-checked .ynab-grid-cell-outflow .currency {\n\tcolor: #ff4b2b;\n\tfont-weight: bold;\n}\n", ""]);

  // exports


  /***/
},
/* 34 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-header-cell {\n    height: 1.6em !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell {\n\theight: 1.6em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n\tpadding-bottom: 0.1em !important;\n\t/*font-size: .850em !important;*/\n}\n\n.toolkit-ynab-grid-cell {\n\theight: 0px !important;\n}\n\n.ynab-grid-body-row {\n\theight: 1.8em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell-checkbox\n.ynab-grid-cell-notification\n.ynab-grid-cell-flag\n.ynab-grid-cell-accountName\n.ynab-grid-cell-date\n.ynab-grid-cell-payeeName\n.ynab-grid-cell-subCategoryName\n.ynab-grid-cell-memo\n.ynab-grid-cell-outflow\n.ynab-grid-cell-inflow\n.ynab-grid-cell-cleared\n{\n\theight: 1.8em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 35 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".toolkit-modal-item-hide-image {\n    visibility: hidden;\n}\n\n.modal-adjust-row-height {\n    background-color: transparent;\n}\n\n.modal-adjust-row-height .modal {\n    padding:.3em 0;\n    width:10.5em;\n    font-size:.9em;\n}\n", ""]);

  // exports


  /***/
},
/* 36 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-header-cell {\n    height: 1.2em !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell {\n\theight: 1.2em !important;\n\ttop: 0 !important;\n\tpadding-top: 0 !important;\n\tpadding-bottom: 0 !important;\n\tfont-size: .90em !important;\n}\n\n/*.ynab-grid-body-row-top.ynab-grid-cell {*/\n.toolkit-ynab-grid-cell {\n\theight: 0px !important;\n}\n\n.ynab-grid-body-row {\n\theight: 1.4em !important;\n\ttop: 0 !important;\n\tpadding-top: 0 !important;\n}\n\n.ynab-grid-cell-checkbox\n.ynab-grid-cell-notification\n.ynab-grid-cell-flag\n.ynab-grid-cell-accountName\n.ynab-grid-cell-date\n.ynab-grid-cell-payeeName\n.ynab-grid-cell-subCategoryName\n.ynab-grid-cell-memo\n.ynab-grid-cell-outflow\n.ynab-grid-cell-inflow\n.ynab-grid-cell-cleared\n{\n\theight: 1.4em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 37 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, "/* Maybe this should play better with reconciled rows that don't have a background-color */\n.ynab-grid .ynab-grid-body-row:nth-of-type(even):not(.is-scheduled):not(.is-checked):not(.is-editing):not(.ynab-grid-body-empty):not(.ynab-grid-actions) {\n\tbackground-color: #fafafa;\n}\n", ""]);

  // exports


  /***/
},
/* 38 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, "/* row */\n.budget-table-row.toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious,\n.budget-table-row.toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious {\n\tbackground-color: #009cc2;\n}\n.budget-table-row.toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious:hover,\n.budget-table-row.toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious:hover {\n\tbackground-color: #1f8ca7;\n}\n\n/* inspector */\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) dt.cautious,\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) dt.cautious {\n\tcolor: #009cc2;\n}\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) dd .cautious,\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) dd .cautious {\n\tbackground: #009cc2;\n}\n\n/* goal */\n.goal-warning .inner-circle {\n\tstroke: #43aecb;\t\n}\n.goal-warning .outer-circle {\n\tfill: #1f8ca7;\n}\n", ""]);

  // exports


  /***/
},
/* 39 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-table-row.is-sub-category > .budget-table-cell-available .positive,\n.budget-table-row.is-sub-category.is-checked.goal-progress > .budget-table-cell-available .positive {\n\tbackground-color: transparent;\n\tcolor: #16a336;\n\tfont-weight: bold;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive:hover,\n.inspector-overview-available .positive {\n\tbackground-color: transparent;\n\tcolor: #138b2e;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\tbackground-color: transparent;\n\tcolor: #cfd5d8;\n\tfont-weight: normal;\n}\n\n.budget-table-row.is-sub-category.is-checked.goal-progress > .budget-table-cell-available .positive\n{\n\tcolor: #16a336;\n\tfont-weight: bold;\n}\n\n.budget-table-row.is-sub-category.is-checked > .budget-table-cell-available .positive,\n.budget-table-row.is-sub-category.is-checked > .budget-table-cell-available .zero {\n\tcolor: #fff;\n}\n\n\n", ""]);

  // exports


  /***/
},
/* 40 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynabtk-stealing-from-next-month {\n\tcolor: red;\n}\n\n.ynabtk-month-link {\n\tcursor: pointer;\n\ttext-decoration: underline;\n}\n", ""]);

  // exports


  /***/
},
/* 41 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-account-row {\n     line-height: normal  !important;\n     padding: 0.025em 0 !important;\n\n}\n", ""]);

  // exports


  /***/
},
/* 42 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-account-row {\n     line-height: normal  !important;\n     padding: 0.01em 0 !important;\n     font-size: .85em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 43 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, "/* ======== General colours / shapes ======== */\n.inspector dt {\n\tcolor: black !important;\n}\n\n/* ======== Cautious colours / shapes ======== */\n.budget-table-row.is-sub-category > .budget-table-cell-available .cautious {\n    background-color: #19a3c5 !important;\n}\n\n.inspector-overview-available .currency.cautious {\n    background-color: #19a3c5 !important;;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .cautious:hover {\n    background-color: #14839e !important;\n}\n\n/* ======== Goal-related colours / shapes ======== */\n.toolkit-row-goal.toolkit-row-availablepositive .budget-table-cell-available .cautious, \n.toolkit-row-goal.toolkit-row-availablezero .budget-table-cell-available .cautious {\n\tbackground: #1282a0 !important;\n}\n.toolkit-row-goal.toolkit-row-availablepositive .budget-table-cell-available .cautious:hover, \n.toolkit-row-goal.toolkit-row-availablezero .budget-table-cell-available .cautious:hover {\n\tbackground: #0e6c85 !important;\n}\n\n.toolkit-row-goal.toolkit-row-availablepositive dd .cautious, \n.toolkit-row-goal.toolkit-row-availablezero dd .cautious {\n\tbackground: #1282a0 !important;\n}\n.toolkit-row-goal.toolkit-row-availablepositive dd .cautious:hover, \n.toolkit-row-goal.toolkit-row-availablezero dd .cautious:hover {\n\tbackground: #0e6c85 !important;\n}\n\n/* ======== Negative colours / shapes ======== */\nul.is-sub-category > li.budget-table-cell-available > div.budget-table-cell-available-div > span.negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n    background-color: #d55e00 !important;\n}\n\n.inspector-overview-available .currency.negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n    background-color: #d55e00 !important;\n}\n\n.left-to-budget-is-negative .budget-header-totals-amount {\n    border-radius: 0em;\n    -webkit-border-radius: 0em;\n    background-color: #d55e00 !important;\n}\n\n.left-to-budget-is-negative .budget-header-totals-amount-arrow .arrow {\n    border-left-color: #d55e00 !important;\n}\n\n/* ======== Positive colours / shapes ======== */\nul.is-sub-category > li.budget-table-cell-available > div.budget-table-cell-available > span.positive {\n    background-color: #009e73 !important;\n    color: #fff !important;\n    font-weight: normal !important;\n}\n\n.inspector-overview-available .currency.positive {\n    background-color: #009e73 !important;;\n    color: #fff !important;\n    font-weight: normal !important;\n}\n", ""]);

  // exports


  /***/
},
/* 44 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-header-days {\n\tdisplay: none;\n\tborder-left: none;\n}\n", ""]);

  // exports


  /***/
},
/* 45 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, "div.referral-program {\n    display: none;\n}\n", ""]);

  // exports


  /***/
},
/* 46 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, "/* ======== Budget Printing Improvements ======== */\n@media print {\n\n\t/* hide unneeded areas */\n\tbody nav.sidebar,\n\tbody aside.budget-inspector,\n\tbody .inspector-resize-handle,\n\tbody .budget-table-row .budget-table-cell-budgeted .goal-indicator {\n\t\tdisplay: none;\n\t}\n\n\n\t/* hide header, yet ensure that month is still visible */\n\tbody .budget-header-item,\n\tbody .budget-header-days.days-of-buffering,\n\tbody .budget-header-item button,\n\tbody .budget-header-calendar .budget-header-calendar-note,\n\tbody .budget-header-calendar .budget-header-calendar-date-button i,\n\tbody .budget-toolbar {\n\t\tdisplay: none;\n\t}\n\tbody .budget-header-days.days-of-buffering {\n\t\tdisplay: none !important;\n\t}\n\tbody .budget-header,\n\tbody .accounts-header {\n\t\tleft: 0;\n\t\tposition: relative;\n\t}\n\tbody .budget-header .budget-header-item,\n\tbody .toolkit-highlight-current-month {\n\t\tbackground: transparent !important;\n\t\tpadding-left: .8em;\n\t}\n\tbody .budget-header-calendar,\n\tbody .budget-header-calendar .budget-header-calendar-date-button {\n\t\tdisplay: block;\n\t\tcolor: #000;\n\t\ttext-align: left;\n\t}\n\n\t/* primarily layout adjustments */\n\t@page { margin: 1cm; }\n\n\t* {\n\t\tflex: none !important;\n\t}\n\tbody .ynab-u {\n\t\tdisplay: block;\n\t}\n\tbody .resize-inspector {\n\t\tdisplay: block !important;\n\t}\n\thtml, body {\n\t\theight: auto;\n\t\toverflow-y: visible !important;\n\t\toverflow-x: hidden !important;\n\t\twidth: 100%;\n\t\tmin-height: 100%;\n\t}\n\tbody div.content,\n\tbody section.budget-content {\n\t\tposition: relative !important;\n\t\twidth: 100%;\n\t\tmin-height: 100%;\n\t\tmin-width: 0;\n\t\ttop: auto;\n\t\tright: auto;\n\t\tbottom: auto;\n\t\tleft: auto;\n\t\toverflow-x: hidden !important;\n\t\tfont-size: 1em;\n\t\tpadding-top: 0;\n\t\tflex: none;\n\t}\n\tbody ul.budget-table-header {\n\t\tposition: relative !important;\n\t\tborder-bottom: 0;\n\t\tmin-width: 0;\n\t\tfont-weight: bold;\n\t}\n\tbody div.budget-table {\n\t\tposition: relative !important;\n\t\ttop: 0;\n\t\tmin-width: 0;\n\t\theight: auto;\n\t\tmin-height: 100%;\n\t\tpadding-bottom: 50px;\n\t}\n\tbody .budget-table-row {\n\t\tpage-break-inside: avoid;\n\t}\n\n\tbody .budget-table-header .budget-table-cell-checkbox,\n\tbody .budget-table-row .budget-table-cell-checkbox,\n\tbody .budget-table-header .budget-table-cell-status,\n\tbody .budget-table-row .budget-table-cell-status {\n\t\tdisplay: none;\n\t}\n\n\tbody .budget-table-header .budget-table-cell-name,\n\tbody .budget-table-row .budget-table-cell-name\n\t{\n\t\twidth: 42% !important;\n\t}\n\t.budget-table-header .budget-table-cell-budgeted,\n\t.budget-table-row .budget-table-cell-budgeted,\n\t.budget-table-header .budget-table-cell-activity,\n\t.budget-table-row .budget-table-cell-activity,\n\t.budget-table-header .budget-table-cell-available,\n\t.budget-table-row .budget-table-cell-available,\n\t.budget-table-header .budget-table-cell-pacing {\n\t\twidth: 12% !important;\n\t\tfont-size: 8pt !important;\n\t}\n\n\tbody .budget-table-row.is-master-category {\n\t\tborder-top: 2px solid #ccc;\n\t\tbackground: transparent;\n\t\tmargin-top: 20px;\n\t\theight: 2.1em;\n\t}\n\tbody .budget-table-row.is-master-category .budget-table-cell-name .budget-table-cell-name-row-label-item {\n\t    padding-top: .3em;\n\t}\n\tbody .budget-table-row.is-master-category:first-child {\n\t\tmargin-top: 0;\n\t}\n\n\tbody .budget-table-row.is-sub-category {\n\t\theight: 1.8em;\n\t}\n\tbody .budget-table-header .budget-table-cell-budgeted,\n\tbody .budget-table-header .budget-table-cell-activity,\n\tbody .budget-table-header .budget-table-cell-available,\n\tbody .budget-table-header .budget-table-cell-pacing {\n\t\tpadding-right: 0 !important;\n\t}\n\n\n\t/* primarily font styling */\n\tbody .budget-table-row.is-master-category .budget-table-cell-name {\n\t\tfont-weight: bold;\n\t}\n\t.budget-table-cell-name-static-width {\n\t\twidth: 18px;\n\t}\n\tbody .budget-table-row.is-master-category .budget-table-cell-name button {\n\t\tfont-weight: bold;\n\t\tposition: relative;\n\t\ttop: 2px !important;\n\t}\n\tbody .button, body .button-red, body .button-disabled {\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-master-category .positive,\n\tbody .budget-table-row.is-master-category .negative,\n\tbody .budget-table-row.is-master-category .cautious,\n\tbody .budget-table-row.is-master-category .zero {\n\t\tfont-weight: bold;\n\t\tcolor: #000;\n\t\tpadding-right: 2px;\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .positive,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .negative,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .cautious,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\t\tbackground-color: transparent;\n\t\tpadding: 0 2px 0 0 !important;\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .positive {\n\t\tcolor: #16a336;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .cautious {\n\t\tcolor: #e59100;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .negative {\n\t\tcolor: #d33c2d;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\t\tcolor: #000000;\n\t}\n\n}\n\n\n/* ======== Account Printing Improvements ======== */\n@media print {\n\n\t/* header layout adjustments */\n\t.accounts-toolbar,\n\t.accounts-header .accounts-header-total-inner .arrow,\n\t.accounts-header-reconcile {\n\t\tdisplay: none;\n\t}\n\t.accounts-header {\n\t\theight: auto;\n\t\tbackground: transparent;\n\t}\n\t.accounts-header .accounts-header-total-inner {\n\t\tpadding-left: 0;\n\t\tpadding-right: 60px;\n\t\tbackground: transparent;\n\t}\n\t.accounts-header .accounts-header-total-inner .accounts-header-total-inner-label,\n\t.accounts-header .accounts-header-balances-label {\n\t\tcolor: #000;\n\t\tline-height: 1.5em;\n\t    font-weight: 400;\n\t}\n\n\t/* transactions adjustments */\n\t.ynab-grid {\n\t\tposition: relative !important;\n\t\theight: auto !important;\n\t\tfont-size: 11pt !important;\n\t}\n\t.ynab-grid-container {\n\t\theight: auto !important;\n\t}\n\t.ynab-grid-header,\n\t.ynab-grid-cell-checkbox {\n\t\tdisplay: none;\n\t}\n\n\t.ynab-grid-body-row,\n\t.ynab-grid-body-row-top,\n\t.ynab-grid-body-row-bottom {\n\t\theight: 26px !important;\n\t\tpage-break-inside: avoid;\n\t}\n\t.ynab-grid-cell {\n\t    padding: .2em 0;\n\t}\n\t.ynab-grid-body-row.is-scheduled {\n\t\tdisplay: none;\n\t}\n\n}", ""]);

  // exports


  /***/
},
/* 47 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(1)(undefined);
  // imports


  // module
  exports.push([module.i, "/* Sidebar Numbers */\n.nav-accounts .negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Accounts Header */\n.accounts-header .accounts-header-total-inner.negative-working-balance {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Bugdet Header */\n.left-to-budget-is-negative .budget-header-totals-amount {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Budget Numbers, pacing */\nli.budget-table-cell-available > div.budget-table-cell-available-div > span.negative,\nli.toolkit-row-availablenegative > budget-table-cell-available-div > span.cautious,\nli.budget-table-cell-pacing span.negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Budget Inspector */\n.inspector-overview-available .currency.negative,\n.toolkit-row-availablenegative .currency.cautious {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n", ""]);

  // exports


  /***/
},
/* 48 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(31);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 49 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(32);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 50 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(33);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 51 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(34);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 52 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(35);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 53 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(36);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 54 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(37);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 55 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(38);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 56 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(39);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 57 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(40);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 58 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(41);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 59 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(42);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 60 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(43);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 61 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(44);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 62 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(45);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 63 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(46);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 64 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(47);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
}]);