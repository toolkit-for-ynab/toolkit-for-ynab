/******/(function (modules) {
  // webpackBootstrap
  /******/ // The module cache
  /******/var installedModules = {};
  /******/
  /******/ // The require function
  /******/function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId]) {
      /******/return installedModules[moduleId].exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/i: moduleId,
      /******/l: false,
      /******/exports: {}
      /******/ };
    /******/
    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/
    /******/ // Flag the module as loaded
    /******/module.l = true;
    /******/
    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/
  }
  /******/
  /******/
  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;
  /******/
  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;
  /******/
  /******/ // identity function for calling harmony imports with the correct context
  /******/__webpack_require__.i = function (value) {
    return value;
  };
  /******/
  /******/ // define getter function for harmony exports
  /******/__webpack_require__.d = function (exports, name, getter) {
    /******/if (!__webpack_require__.o(exports, name)) {
      /******/Object.defineProperty(exports, name, {
        /******/configurable: false,
        /******/enumerable: true,
        /******/get: getter
        /******/ });
      /******/
    }
    /******/
  };
  /******/
  /******/ // getDefaultExport function for compatibility with non-harmony modules
  /******/__webpack_require__.n = function (module) {
    /******/var getter = module && module.__esModule ?
    /******/function getDefault() {
      return module['default'];
    } :
    /******/function getModuleExports() {
      return module;
    };
    /******/__webpack_require__.d(getter, 'a', getter);
    /******/return getter;
    /******/
  };
  /******/
  /******/ // Object.prototype.hasOwnProperty.call
  /******/__webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/
  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "";
  /******/
  /******/ // Load entry module and return exports
  /******/return __webpack_require__(__webpack_require__.s = 15);
  /******/
})(
/************************************************************************/
/******/[
/* 0 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_listeners__ = __webpack_require__(4);

  class Feature {
    constructor() {
      this.settings = {
        enabled: ynabToolKit.options[this.constructor.name]
      };
    }

    shouldInvoke() {
      // Default to no action. Unless you're implementing a CSS only feature,
      // you MUST override this to specify when your invoke() function should run!
      return false;
    }

    willInvoke() {
      /* stubbed optional hook for logic that must happen for a feature
      to work but doesn't need to happen on every invoke */
    }

    invoke() {
      throw Error(`Feature: ${this.constructor.name} does not implement required invoke() method.`);
    }

    injectCSS() {/* stubbed, default to no injected CSS */}

    observe() {/* stubbed listener function */}

    onRouteChanged() {/* stubbed listener function */}

    onBudgetChanged() {/* stubbed listener function */}

    applyListeners() {
      let observeListener = new __WEBPACK_IMPORTED_MODULE_0_core_listeners__["a" /* ObserveListener */]();
      observeListener.addFeature(this);

      let routeChangeListener = new __WEBPACK_IMPORTED_MODULE_0_core_listeners__["b" /* RouteChangeListener */]();
      routeChangeListener.addFeature(this);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = Feature;

  /***/
},
/* 1 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony export (immutable) */
  __webpack_exports__["a"] = controllerLookup;
  /* harmony export (immutable) */__webpack_exports__["h"] = componentLookup;
  /* harmony export (immutable) */__webpack_exports__["c"] = getEmberView;
  /* harmony export (immutable) */__webpack_exports__["b"] = getCurrentRouteName;
  /* unused harmony export getCategoriesViewModel */
  /* harmony export (immutable) */__webpack_exports__["f"] = getAllBudgetMonthsViewModel;
  /* harmony export (immutable) */__webpack_exports__["g"] = getCurrentDate;
  /* harmony export (immutable) */__webpack_exports__["e"] = formatCurrency;
  /* harmony export (immutable) */__webpack_exports__["i"] = getToolkitStorageKey;
  /* harmony export (immutable) */__webpack_exports__["j"] = setToolkitStorageKey;
  /* harmony export (immutable) */__webpack_exports__["d"] = transitionTo;
  const storageKeyPrefix = 'ynab-toolkit-';

  function controllerLookup(controllerName) {
    return containerLookup(`controller:${controllerName}`);
  }

  function componentLookup(componentName) {
    return containerLookup(`component:${componentName}`);
  }

  function getEmberView(viewId) {
    return getViewRegistry()[viewId];
  }

  function getCurrentRouteName() {
    let applicationController = controllerLookup('application');
    return applicationController.get('currentRouteName');
  }

  function getCategoriesViewModel() {
    return ynab.YNABSharedLib.getBudgetViewModel_CategoriesViewModel();
  }

  function getAllBudgetMonthsViewModel() {
    return ynab.YNABSharedLib.getBudgetViewModel_AllBudgetMonthsViewModel();
  }

  function getCurrentDate(format) {
    return ynabDate(format, false);
  }

  function formatCurrency(value) {
    let userCurrency = ynab.YNABSharedLib.currencyFormatter.getCurrency();
    let currencyFormatter = new ynab.formatters.CurrencyFormatter();
    currencyFormatter.initialize(userCurrency);
    userCurrency = currencyFormatter.getCurrency();

    let formattedCurrency = currencyFormatter.format(value).toString();
    if (userCurrency.symbol_first) {
      if (formattedCurrency.charAt(0) === '-') {
        formattedCurrency = `-${userCurrency.currency_symbol}${formattedCurrency.slice(1)}`;
      } else {
        formattedCurrency = `${userCurrency.currency_symbol}${formattedCurrency}`;
      }
    } else {
      formattedCurrency = `${formattedCurrency}${userCurrency.currency_symbol}`;
    }

    return formattedCurrency;
  }

  function getToolkitStorageKey(key, type) {
    let value = localStorage.getItem(storageKeyPrefix + key);

    switch (type) {
      case 'boolean':
        return value === 'true';
      case 'number':
        return Number(value);
      default:
        return value;
    }
  }

  function setToolkitStorageKey(key, value) {
    return localStorage.setItem(storageKeyPrefix + key, value);
  }

  function transitionTo() {
    const router = containerLookup('router:main');
    router.transitionTo(...arguments);
  }

  /* Private Functions */
  function getViewRegistry() {
    return Ember.Component.create().get('_viewRegistry');
  }

  function containerLookup(containerName) {
    const viewRegistry = getViewRegistry();
    const viewId = Ember.keys(viewRegistry)[0];
    const view = viewRegistry[viewId];

    let container;
    try {
      container = view.container.lookup(containerName);
    } catch (e) {
      container = view.container.factoryCache[containerName];
    }

    return container;
  }

  function ynabDate(format) {
    if (typeof format !== 'string') {
      return ynab.YNABSharedLib.dateFormatter.formatDate();
    }

    return ynab.YNABSharedLib.dateFormatter.formatDate(moment(), format);
  }

  /***/
},
/* 2 */
/***/function (module, exports) {

  /*
  	MIT License http://www.opensource.org/licenses/mit-license.php
  	Author Tobias Koppers @sokra
  */
  // css base code, injected by the css-loader
  module.exports = function (useSourceMap) {
    var list = [];

    // return the list of modules as css string
    list.toString = function toString() {
      return this.map(function (item) {
        var content = cssWithMappingToString(item, useSourceMap);
        if (item[2]) {
          return "@media " + item[2] + "{" + content + "}";
        } else {
          return content;
        }
      }).join("");
    };

    // import a list of modules into the list
    list.i = function (modules, mediaQuery) {
      if (typeof modules === "string") modules = [[null, modules, ""]];
      var alreadyImportedModules = {};
      for (var i = 0; i < this.length; i++) {
        var id = this[i][0];
        if (typeof id === "number") alreadyImportedModules[id] = true;
      }
      for (i = 0; i < modules.length; i++) {
        var item = modules[i];
        // skip already imported module
        // this implementation is not 100% perfect for weird media query combinations
        //  when a module is imported multiple times with different media queries.
        //  I hope this will never occur (Hey this way we have smaller bundles)
        if (typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
          if (mediaQuery && !item[2]) {
            item[2] = mediaQuery;
          } else if (mediaQuery) {
            item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
          }
          list.push(item);
        }
      }
    };
    return list;
  };

  function cssWithMappingToString(item, useSourceMap) {
    var content = item[1] || '';
    var cssMapping = item[3];
    if (!cssMapping) {
      return content;
    }

    if (useSourceMap && typeof btoa === 'function') {
      var sourceMapping = toComment(cssMapping);
      var sourceURLs = cssMapping.sources.map(function (source) {
        return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */';
      });

      return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
    }

    return [content].join('\n');
  }

  // Adapted from convert-source-map (MIT)
  function toComment(sourceMap) {
    // eslint-disable-next-line no-undef
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
    var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;

    return '/*# ' + data + ' */';
  }

  /***/
},
/* 3 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0__accounts_autoCloseReconcile__ = __webpack_require__(7);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__accounts_customFlagNames__ = __webpack_require__(8);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_2__accounts_runningBalance__ = __webpack_require__(9);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_3__accounts_showCategoryBalance__ = __webpack_require__(10);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_4__budget_display_goal_amount__ = __webpack_require__(11);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_5__budget_stealing_from_future__ = __webpack_require__(12);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_6__budget_target_balance_warning__ = __webpack_require__(13);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_7__general_hide_referral_banner__ = __webpack_require__(14);
  /*
   ***********************************************************
   * Warning: This is a file generated by the build process. *
   *                                                         *
   * Any changes you make manually will be overwritten       *
   * the next time you run webpack!                          *
   ***********************************************************
  */

  const features = [__WEBPACK_IMPORTED_MODULE_0__accounts_autoCloseReconcile__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__accounts_customFlagNames__["a" /* default */], __WEBPACK_IMPORTED_MODULE_2__accounts_runningBalance__["a" /* default */], __WEBPACK_IMPORTED_MODULE_3__accounts_showCategoryBalance__["a" /* default */], __WEBPACK_IMPORTED_MODULE_4__budget_display_goal_amount__["a" /* default */], __WEBPACK_IMPORTED_MODULE_5__budget_stealing_from_future__["a" /* default */], __WEBPACK_IMPORTED_MODULE_6__budget_target_balance_warning__["a" /* default */], __WEBPACK_IMPORTED_MODULE_7__general_hide_referral_banner__["a" /* default */]];

  /* harmony default export */__webpack_exports__["a"] = features;

  /***/
},
/* 4 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0__observeListener__ = __webpack_require__(5);
  /* harmony reexport (binding) */__webpack_require__.d(__webpack_exports__, "a", function () {
    return __WEBPACK_IMPORTED_MODULE_0__observeListener__["a"];
  });
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__routeChangeListener__ = __webpack_require__(6);
  /* harmony reexport (binding) */__webpack_require__.d(__webpack_exports__, "b", function () {
    return __WEBPACK_IMPORTED_MODULE_1__routeChangeListener__["a"];
  });

  /***/
},
/* 5 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";

  let instance = null;

  class ObserveListener {
    constructor() {
      if (instance) {
        return instance;
      }

      this.features = [];

      let _MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
      let observer = new _MutationObserver(mutations => {
        this.changedNodes = new Set();

        mutations.forEach(mutation => {
          let newNodes = mutation.target;
          let $nodes = $(newNodes);

          $nodes.each((index, element) => {
            var nodeClass = $(element).attr('class');
            if (nodeClass) {
              this.changedNodes.add(nodeClass.replace(/^ember-view /, ''));
            }
          });
        });

        // Now we are ready to feed the change digest to the
        // automatically setup feedChanges file/function
        if (this.changedNodes.size > 0) {
          this.emitChanges();
        }
      });

      // This finally says 'Watch for changes' and only needs to be called the one time
      observer.observe($('.ember-view.layout')[0], {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['class']
      });

      return instance;
    }

    addFeature(feature) {
      if (this.features.indexOf(feature) === -1) {
        this.features.push(feature);
      }
    }

    emitChanges() {
      this.features.forEach(feature => {
        Ember.run.later(feature.observe.bind(feature, this.changedNodes), 0);
      });
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = ObserveListener;

  /***/
},
/* 6 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__ = __webpack_require__(1);

  let instance = null;

  class RouteChangeListener {
    constructor() {
      if (instance) {
        return instance;
      }

      let routeChangeListener = this;
      routeChangeListener.features = [];

      let applicationController = __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0_helpers_toolkit__["a" /* controllerLookup */])('application');
      applicationController.reopen({
        onRouteChanged: Ember.observer('currentRouteName', // this will handle accounts -> budget and vise versa
        'budgetVersionId', // this will handle changing budgets
        'selectedAccountId', // this will handle switching around accounts
        'monthString', // this will handle changing which month of a budget you're looking at
        (controller, changedProperty) => {
          if (changedProperty === 'budgetVersionId') {
            Ember.run.scheduleOnce('afterRender', controller, 'emitBudgetRouteChange');
          } else {
            Ember.run.scheduleOnce('afterRender', controller, 'emitSameBudgetRouteChange');
          }
        }),

        emitSameBudgetRouteChange: function () {
          let currentRoute = applicationController.get('currentRouteName');
          routeChangeListener.features.forEach(feature => {
            setTimeout(feature.onRouteChanged.bind(feature, currentRoute), 0);
          });
        },

        emitBudgetRouteChange: function () {
          let currentRoute = applicationController.get('currentRouteName');
          routeChangeListener.features.forEach(feature => {
            setTimeout(feature.onBudgetChanged.bind(feature, currentRoute), 0);
          });
        }
      });

      instance = this;
    }

    addFeature(feature) {
      if (this.features.indexOf(feature) === -1) {
        this.features.push(feature);
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = RouteChangeListener;

  /***/
},
/* 7 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(1);

  class AutoCloseReconcile extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* default */] {
    observe(changedNodes) {
      if (changedNodes.has('modal-account-reconcile-current') && changedNodes.has('flaticon stroke checkmark-2')) {
        Ember.run.later(() => {
          const applicationController = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["a" /* controllerLookup */]('application');
          applicationController.send('closeModal');
        }, 1500);
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = AutoCloseReconcile;

  /***/
},
/* 8 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(1);

  let flags;
  let redFlagLabel;
  let blueFlagLabel;
  let orangeFlagLabel;
  let yellowFlagLabel;
  let greenFlagLabel;
  let purpleFlagLabel;

  class CustomFlagNames extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* default */] {
    constructor() {
      super();
      if (!__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["i" /* getToolkitStorageKey */]('flags')) {
        this.storeDefaultFlags();
      }
      if (typeof flags === 'undefined') {
        flags = JSON.parse(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["i" /* getToolkitStorageKey */]('flags'));
        this.updateFlagLabels();
      }
    }

    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('account') !== -1;
    }

    invoke() {
      $('.ynab-grid-cell-flag .ynab-flag-red').parent().attr('title', redFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-blue').parent().attr('title', blueFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-orange').parent().attr('title', orangeFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-yellow').parent().attr('title', yellowFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-green').parent().attr('title', greenFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-purple').parent().attr('title', purpleFlagLabel);
    }

    observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('layout user-logged-in') || changedNodes.has('ynab-grid-body')) {
        this.invoke();
      }

      if (changedNodes.has('ynab-u modal-popup modal-account-flags ember-view modal-overlay active')) {
        $('.ynab-flag-red .label, .ynab-flag-red .label-bg').text(redFlagLabel);
        $('.ynab-flag-blue .label, .ynab-flag-blue .label-bg').text(blueFlagLabel);
        $('.ynab-flag-orange .label, .ynab-flag-orange .label-bg').text(orangeFlagLabel);
        $('.ynab-flag-yellow .label, .ynab-flag-yellow .label-bg').text(yellowFlagLabel);
        $('.ynab-flag-green .label, .ynab-flag-green .label-bg').text(greenFlagLabel);
        $('.ynab-flag-purple .label, .ynab-flag-purple .label-bg').text(purpleFlagLabel);

        $('.modal-account-flags .modal').css({ height: '22em' }).append($('<div>', { id: 'account-flags-actions' }).css({ padding: '0 .3em' }).append($('<button>', { id: 'flags-edit', class: 'button button-primary' }).append('Edit ').append($('<i>', { class: 'flaticon stroke compose-3' }))));

        this.addEventListeners();
      }
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;

      this.invoke();
    }

    addEventListeners() {
      let $this = this;
      $('#flags-edit').click(function () {
        $('.modal-account-flags .modal-list').empty();

        for (let key in flags) {
          let flag = flags[key];

          $('.modal-account-flags .modal-list').append($('<li>').append($('<input>', { id: key, type: 'text', class: 'flag-input', value: flag.label, placeholder: flag.label }).css({ color: '#fff', fill: flag.color, 'background-color': flag.color, height: 30, padding: '0 .7em', 'margin-bottom': '.3em', border: 'none' })));
        }

        $('#account-flags-actions').empty();

        $('#account-flags-actions').append($('<button>', { id: 'flags-close', class: 'button button-primary' }).append('Ok ').append($('<i>', { class: 'flaticon stroke checkmark-2' })));

        $('input.flag-input').focus(function () {
          $(this).css({
            color: '#000'
          });
        });

        $('input.flag-input').blur(function () {
          $(this).css({
            color: '#fff'
          });
          $this.saveFlag($(this));
        });

        $('#flags-close').click(function () {
          $('.modal-overlay').click();
        });
      });
    }

    saveFlag(flag) {
      if (flag.attr('placeholder') !== flag.val()) {
        let key = flag.attr('id');

        flags[key].label = flag.val();
        __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["j" /* setToolkitStorageKey */]('flags', JSON.stringify(flags));

        this.updateFlagLabels();
        this.invoke();
      }
    }

    updateFlagLabels() {
      redFlagLabel = flags.red.label;
      blueFlagLabel = flags.blue.label;
      orangeFlagLabel = flags.orange.label;
      yellowFlagLabel = flags.yellow.label;
      greenFlagLabel = flags.green.label;
      purpleFlagLabel = flags.purple.label;
    }

    storeDefaultFlags() {
      const flagsJSON = {
        red: {
          label: 'Red',
          color: '#d43d2e'
        },
        orange: {
          label: 'Orange',
          color: '#ff7b00'
        },
        yellow: {
          label: 'Yellow',
          color: '#f8e136'
        },
        green: {
          label: 'Green',
          color: '#9ac234'
        },
        blue: {
          label: 'Blue',
          color: '#0082cb'
        },
        purple: {
          label: 'Purple',
          color: '#9384b7'
        }
      };
      __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["j" /* setToolkitStorageKey */]('flags', JSON.stringify(flagsJSON));
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = CustomFlagNames;

  /***/
},
/* 9 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(1);

  class RunningBalance extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* default */] {
    injectCSS() {
      return __webpack_require__(19);
    }

    willInvoke() {
      this.addWillInsertRunningBalanceRow('register/grid-sub');
      this.addWillInsertRunningBalanceRow('register/grid-row');
      this.addWillInsertRunningBalanceRow('register/grid-scheduled');

      return initializeRunningBalances();
    }

    // we always want to invoke this feature if it's enabled because we want
    // to at least initialize running balance on all of the accounts
    shouldInvoke() {
      const applicationController = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["a" /* controllerLookup */]('application');
      return applicationController.get('selectedAccountId') !== null;
    }

    addWillInsertRunningBalanceRow(componentName) {
      const _this = this;
      const GridComponent = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["h" /* componentLookup */](componentName);

      if (GridComponent.__toolkitInitialized) {
        return;
      }

      GridComponent.constructor.reopen({
        willInsertElement: function () {
          if (!_this.shouldInvoke()) {
            return;
          }
          willInsertRunningBalanceRow.call(this);
        }
      });

      GridComponent.__toolkitInitialized = true;
    }

    addDeadColumnOnInsert(componentName) {
      const _this = this;
      const GridComponent = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["h" /* componentLookup */](componentName);

      if (GridComponent.__toolkitInitialized) {
        return;
      }

      GridComponent.reopen({
        willInsertElement: function () {
          if (!_this.shouldInvoke()) {
            return;
          }
          $('<div class="ynab-grid-cell ynab-toolkit-grid-cell-running-balance">').insertAfter($('.ynab-grid-cell-inflow', this.get('element')));
        }
      });

      // this is really hacky but I'm not sure what else to do, most of these components
      // double render so the `willInsertElement` works for those but the add rows
      // and footer are weird. add-rows doesn't double render and will work every time
      // after the component has been cached but footer is _always_ a new component WutFace
      let $appendToRow;
      switch (componentName) {
        case 'register/grid-add':
          $appendToRow = $('.ynab-grid-add-rows .ynab-grid-body-row.is-editing');
          break;
        case 'register/grid-footer':
          $appendToRow = $('.ynab-grid-body-row.ynab-grid-footer');
          break;
      }

      if ($('.ynab-toolkit-grid-cell-running-balance', $appendToRow).length === 0) {
        $('<div class="ynab-grid-cell ynab-toolkit-grid-cell-running-balance">').insertAfter($('.ynab-grid-cell-inflow', $appendToRow));
      }

      GridComponent.__toolkitInitialized = true;
    }

    invoke() {
      insertHeader();

      if ($('.ynab-grid-body-row.is-editing', '.ynab-grid-body').length) {
        this.addDeadColumnOnInsert('register/grid-edit');
      }

      if ($('.ynab-grid-add-rows', '.ynab-grid').length) {
        this.addDeadColumnOnInsert('register/grid-add');
      }

      if ($('.ynab-grid-body-split.is-editing', '.ynab-grid').length) {
        this.addDeadColumnOnInsert('register/grid-sub-edit');
      }

      if ($('.ynab-grid-body-row.ynab-grid-footer', '.ynab-grid').length) {
        this.addDeadColumnOnInsert('register/grid-footer');
      }
    }

    observe(changedNodes) {
      if (!this.shouldInvoke()) {
        $('.ynab-toolkit-grid-cell-running-balance').remove();
        return;
      }

      if (changedNodes.has('ynab-grid-body') || changedNodes.has('ynab-grid')) {
        this.invoke();
      }
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = RunningBalance;

  // Using ._result here bcause we can guarantee that we've already invoked the
  // getBudgetViewModel_AccountTransactionsViewModel() function when we initialized
  function calculateRunningBalance(accountId) {
    const accountsController = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["a" /* controllerLookup */]('accounts');
    const accountViewModel = ynab.YNABSharedLib.defaultInstance.getBudgetViewModel_AccountTransactionsViewModel(accountId)._result;

    const transactions = accountViewModel.get('visibleTransactionDisplayItems');
    const sorted = transactions.slice().sort((a, b) => {
      var propA = a.get('date');
      var propB = b.get('date');

      if (propA instanceof ynab.utilities.DateWithoutTime) propA = propA.getUTCTime();
      if (propB instanceof ynab.utilities.DateWithoutTime) propB = propB.getUTCTime();

      var res = Ember.compare(propA, propB);

      if (res === 0) {
        res = Ember.compare(a.getAmount(), b.getAmount());
        if (accountsController.get('sortAscending')) {
          return res;
        }

        return -res;
      }

      return res;
    });

    let runningBalance = 0;
    sorted.forEach(transaction => {
      if (transaction.get('parentEntityId') !== null) {
        transaction.__ynabToolKitRunningBalance = runningBalance;
        return;
      }

      if (transaction.get('inflow')) {
        runningBalance += transaction.get('inflow');
      } else if (transaction.get('outflow')) {
        runningBalance -= transaction.get('outflow');
      }

      transaction.__ynabToolKitRunningBalance = runningBalance;
    });
  }

  function initializeRunningBalances() {
    return ynab.YNABSharedLib.defaultInstance.entityManager.accountsCollection.forEach(account => {
      return ynab.YNABSharedLib.defaultInstance.getBudgetViewModel_AccountTransactionsViewModel(account.entityId).then(accountViewModel => {
        calculateRunningBalance(account.entityId);

        // can you believe it? YNAB has this really interestingly name field
        // on visibleTransactionDisplayItems that sounds exactly like what I need
        // if something changes in that list, you tell me about it, and I'll update
        // the running balance for the account make sure our users always see the fancy
        accountViewModel.get('visibleTransactionDisplayItems').addObserver('anyItemChangedCounter', function () {
          calculateRunningBalance(account.entityId);
        });
      });
    });
  }

  function willInsertRunningBalanceRow() {
    const selectedAccountId = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["a" /* controllerLookup */]('application');
    if (!selectedAccountId) {
      return;
    }

    const $currentRow = $(this.element);
    const currentRowRunningBalance = $('.ynab-grid-cell-inflow', $currentRow).clone();
    currentRowRunningBalance.removeClass('ynab-grid-cell-inflow');
    currentRowRunningBalance.addClass('ynab-toolkit-grid-cell-running-balance');

    const transaction = this.get('content');

    let runningBalance = transaction.__ynabToolKitRunningBalance;
    if (typeof runningBalance === 'undefined') {
      calculateRunningBalance(selectedAccountId);
      runningBalance = transaction.__ynabToolKitRunningBalance;
    }

    const currencySpan = $('.user-data', currentRowRunningBalance);
    if (runningBalance < 0) {
      currencySpan.addClass('user-data currency negative');
    } else if (runningBalance > 0) {
      currencySpan.addClass('user-data currency positive');
    } else {
      currencySpan.addClass('user-data currency zero');
    }

    if (transaction.get('parentEntityId') !== null) {
      currencySpan.text('');
    } else {
      currencySpan.text(ynabToolKit.shared.formatCurrency(runningBalance));
    }

    currentRowRunningBalance.insertAfter($('.ynab-grid-cell-inflow', $currentRow));
  }

  function insertHeader() {
    if ($('.ynab-grid-header .ynab-toolkit-grid-cell-running-balance').length) return;

    var $headerRow = $('.ynab-grid-header');
    var runningBalanceHeader = $('.ynab-grid-cell-inflow', $headerRow).clone();
    runningBalanceHeader.removeClass('ynab-grid-cell-inflow');
    runningBalanceHeader.addClass('ynab-toolkit-grid-cell-running-balance');
    runningBalanceHeader.text('RUNNING BALANCE');
    runningBalanceHeader.insertAfter($('.ynab-grid-cell-inflow', $headerRow));

    if ($('.ynab-grid-body .ynab-grid-body-row-top .ynab-toolkit-grid-cell-running-balance').length) return;
    var $topRow = $('.ynab-grid-body-row-top');
    var topRowRunningBalance = $('.ynab-grid-cell-inflow', $topRow).clone();
    topRowRunningBalance.removeClass('ynab-grid-cell-inflow');
    topRowRunningBalance.addClass('ynab-toolkit-grid-cell-running-balance');
    topRowRunningBalance.insertAfter($('.ynab-grid-cell-inflow', $topRow));
  }

  /***/
},
/* 10 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(1);

  class ShowCategoryBalance extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* default */] {
    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('account') !== -1;
    }

    invoke() {
      __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["f" /* getAllBudgetMonthsViewModel */]().then(allBudgetMonthsViewModel => {
        let subCategoryCalculations = allBudgetMonthsViewModel.get('monthlySubCategoryBudgetCalculationsCollection');
        let categoryLookupPrefix = `mcbc/${__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["g" /* getCurrentDate */]('YYYY-MM')}`;

        let GridSubComponent = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["h" /* componentLookup */]('register/grid-sub');
        GridSubComponent.constructor.reopen({
          didRender: function () {
            didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });

        let GridRowComponent = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["h" /* componentLookup */]('register/grid-row');
        GridRowComponent.constructor.reopen({
          didRender: function () {
            didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });

        let GridScheduledComponent = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["h" /* componentLookup */]('register/grid-scheduled');
        GridScheduledComponent.constructor.reopen({
          didRender: function () {
            didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });
      });
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;

      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = ShowCategoryBalance;

  function didRender(subCategoryCalculations, categoryLookupPrefix) {
    let element = this.get('element');
    let subCategoryId = this.get('content.subCategoryId');
    let budgetData = subCategoryCalculations.findItemByEntityId(`${categoryLookupPrefix}/${subCategoryId}`);

    // if there's no budget data (could be an income/credit category) skip it.
    if (!budgetData) return;

    let title = $('.ynab-grid-cell-subCategoryName', element).attr('title');
    let newTitle = `${title} (Balance: ${__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["e" /* formatCurrency */](budgetData.get('balance'))})`;
    $('.ynab-grid-cell-subCategoryName', element).attr('title', newTitle);
  }

  /***/
},
/* 11 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(1);

  class DisplayTargetGoalAmount extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* default */] {
    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('budget') !== -1;
    }

    invoke() {
      $('.budget-table-header .budget-table-cell-name').css('position', 'relative');
      $('.budget-table-row.is-sub-category li.budget-table-cell-name').css('position', 'relative');

      $('.budget-table-header .budget-table-cell-name').append($('<div>', { class: 'budget-table-cell-goal' }).css({ position: 'absolute', right: 0, top: '6px' }).append('GOAL'));

      $('.budget-table-row.is-sub-category li.budget-table-cell-name').append($('<div>', { class: 'budget-table-cell-goal currency' }).css({
        background: '-webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 10%,rgba(255,255,255,1) 100%)', position: 'absolute', 'font-size': '80%', 'padding-left': '.75em', 'padding-right': '1px', 'line-height': '2.55em'
      }));

      $('.budget-table-row.is-sub-category').each((index, element) => {
        const emberId = element.id;
        const viewData = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["c" /* getEmberView */](emberId).data;
        const { subCategory } = viewData;
        const { monthlySubCategoryBudget } = viewData;
        const { monthlySubCategoryBudgetCalculation } = viewData;
        const goalType = subCategory.get('goalType');
        const monthlyFunding = subCategory.get('monthlyFunding');
        const targetBalance = subCategory.get('targetBalance');
        const targetBalanceDate = monthlySubCategoryBudgetCalculation.get('goalTarget');
        const budgetedAmount = monthlySubCategoryBudget.get('budgeted');
        const activity = Math.abs(monthlySubCategoryBudgetCalculation.get('cashOutflows'));
        if (goalType === 'MF') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["e" /* formatCurrency */](monthlyFunding));
          if (activity <= monthlyFunding && budgetedAmount >= monthlyFunding) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          } else if (activity > monthlyFunding) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: 'grey' });
          }
        } else if (goalType === 'TB') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["e" /* formatCurrency */](targetBalance));
          if (activity <= targetBalance && budgetedAmount >= targetBalance) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          } else if (activity > targetBalance) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: 'grey' });
          }
        } else if (goalType === 'TBD') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(__WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["e" /* formatCurrency */](targetBalanceDate));
          if (activity <= targetBalanceDate && budgetedAmount >= targetBalanceDate) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          } else if (activity > targetBalanceDate) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: 'grey' });
          }
        }
      });
    }

    observe(changedNodes) {
      if (!this.shouldInvoke()) return;
      if (changedNodes.has('budget-table-cell-budgeted')) {
        $('.budget-table-cell-goal').remove();
        this.invoke();
      }
      if (changedNodes.has('budget-table-row is-sub-category') || changedNodes.has('budget-table-row is-sub-category is-checked') || changedNodes.has('budget-table-cell-goal currency')) {
        $('.budget-table-row.is-sub-category li.budget-table-cell-name .budget-table-cell-goal').css({
          background: '-webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 10%,rgba(255,255,255,1) 100%)' });
        $('.budget-table-row.is-checked li.budget-table-cell-name .budget-table-cell-goal').css({ background: '#005a6e' });
      }
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = DisplayTargetGoalAmount;

  /***/
},
/* 12 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(1);

  // TODO: move income-from-last-month to the new framework and just export this
  // variable from that feature
  const INCOME_FROM_LAST_MONTH_CLASSNAME = 'income-from-last-month';

  class TargetBalanceWarning extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* default */] {
    injectCSS() {
      return __webpack_require__(20);
    }

    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('budget') !== -1;
    }

    isMonthABeforeB(a, b) {
      if (b === null) return true;

      const [yearA, monthA] = a.split('-').map(val => parseInt(val));
      const [yearB, monthB] = b.split('-').map(val => parseInt(val));
      if (yearA >= yearB && monthA >= monthB) {
        return false;
      }

      return true;
    }

    onAvailableToBudgetChange(budgetViewModel) {
      let earliestEntityDate = null;
      let earliestNegativeMonth = null;
      let earliestNegativeMonthCalculation = null;
      budgetViewModel.get('allBudgetMonthsViewModel.monthlyBudgetCalculationsCollection').forEach(monthCalculation => {
        if (this.isMonthEntityIdFuture(monthCalculation.get('entityId'))) {
          const entityDate = monthCalculation.get('entityId').match(/mbc\/(.*)\/.*/)[1];
          const entityMonth = entityDate.split('-').map(val => parseInt(val))[1];

          if (monthCalculation.get('availableToBudget') < 0 && this.isMonthABeforeB(entityDate, earliestEntityDate)) {
            earliestEntityDate = entityDate;
            earliestNegativeMonth = entityMonth;
            earliestNegativeMonthCalculation = monthCalculation;
          }
        }
      });

      // there's no easy class name on the thing we want to highlight so
      // we have to just select the specific row. if the user has the income
      // from last month feature on and it has already invoked, then the row
      // we want is number 4, else 3.
      let futureBudgetRow = 3;
      if (ynabToolKit.options.incomeFromLastMonth !== '0') {
        if ($(`.budget-header-totals-details-values .${INCOME_FROM_LAST_MONTH_CLASSNAME}`).length) {
          futureBudgetRow = 4;
        }
      }

      const value = $('.budget-header-totals-details-values .budget-header-totals-cell-value').eq(futureBudgetRow);
      const name = $('.budget-header-totals-details-names .budget-header-totals-cell-name').eq(futureBudgetRow);

      // no negative months! good job team!
      if (earliestNegativeMonth === null) {
        value.removeClass('ynabtk-stealing-from-next-month');
        name.removeClass('ynabtk-stealing-from-next-month');
        $('#ynabtk-stealing-amount', name).remove();
        return;
      }

      value.addClass('ynabtk-stealing-from-next-month');
      name.addClass('ynabtk-stealing-from-next-month');

      const availableToBudget = earliestNegativeMonthCalculation.getAvailableToBudget();
      $('#ynabtk-stealing-amount', name).remove();
      name.append('<span id="ynabtk-stealing-amount"> (' + '<strong>' + `${ynab.formatCurrency(availableToBudget)} in ` + `<a class="ynabtk-month-link">${ynabToolKit.shared.monthsFull[earliestNegativeMonth - 1]}</a>` + '</strong>' + ')</span>');

      $('.ynabtk-month-link', name).click(event => {
        event.preventDefault();
        const applicationController = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["a" /* controllerLookup */]('application');
        const budgetVersionId = applicationController.get('budgetVersionId');
        __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["d" /* transitionTo */]('budget.select', budgetVersionId, earliestEntityDate.replace('-', ''));
      });
    }

    isMonthEntityIdFuture(entityId) {
      const currentYear = parseInt(moment().format('YYYY'));
      const currentMonth = parseInt(moment().format('MM'));
      const entityDate = entityId.match(/mbc\/(.*)\/.*/)[1];
      const [entityYear, entityMonth] = entityDate.split('-').map(val => parseInt(val));
      if (entityYear >= currentYear && entityMonth > currentMonth) {
        return true;
      }

      return false;
    }

    invoke() {
      let budgetController = ynabToolKit.shared.containerLookup('controller:budget');
      let budgetViewModel = budgetController.get('budgetViewModel');
      if (budgetViewModel) {
        budgetViewModel.get('allBudgetMonthsViewModel.monthlyBudgetCalculationsCollection').forEach(month => {
          month.addObserver('availableToBudget', this.onAvailableToBudgetChange.bind(this, budgetViewModel));
        });

        this.onAvailableToBudgetChange(budgetViewModel);
      }
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = TargetBalanceWarning;

  /***/
},
/* 13 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__ = __webpack_require__(1);

  class TargetBalanceWarning extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* default */] {
    constructor() {
      super();
    }

    shouldInvoke() {
      return __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["b" /* getCurrentRouteName */]().indexOf('budget') !== -1;
    }

    invoke() {
      $('.budget-table-row.is-sub-category').each((index, element) => {
        const emberId = element.id;
        const viewData = __WEBPACK_IMPORTED_MODULE_1_helpers_toolkit__["c" /* getEmberView */](emberId).data;
        const { subCategory } = viewData;

        if (subCategory.get('goalType') === ynab.constants.SubCategoryGoalType.TargetBalance) {
          const available = viewData.get('available');
          const targetBalance = subCategory.get('targetBalance');
          const currencyElement = $('.budget-table-cell-available .user-data.currency', element);

          if (available < targetBalance && !currencyElement.hasClass('cautious')) {
            if (currencyElement.hasClass('positive')) {
              currencyElement.removeClass('positive');
            }

            currencyElement.addClass('cautious');
          }
        }
      });
    }

    observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('budget-table-cell-available-div user-data')) {
        this.invoke();
      }
    }

    onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = TargetBalanceWarning;

  /***/
},
/* 14 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony import */
  var __WEBPACK_IMPORTED_MODULE_0_core_feature__ = __webpack_require__(0);

  class HideReferralBanner extends __WEBPACK_IMPORTED_MODULE_0_core_feature__["a" /* default */] {
    injectCSS() {
      return __webpack_require__(21);
    }
  }
  /* harmony export (immutable) */__webpack_exports__["a"] = HideReferralBanner;

  /***/
},
/* 15 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";

  Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_features__ = __webpack_require__(3);

  const featureInstances = __WEBPACK_IMPORTED_MODULE_0_features__["a" /* default */].map(Feature => new Feature());

  // This poll() function will only need to run until we find that the DOM is ready
  (function poll() {
    if (typeof Em !== 'undefined' && typeof Ember !== 'undefined' && typeof $ !== 'undefined' && $('.ember-view.layout').length && typeof ynabToolKit !== 'undefined') {
      // Gather any desired global CSS from features
      let globalCSS = '';

      featureInstances.forEach(feature => {
        if (feature.settings.enabled && feature.injectCSS()) {
          globalCSS += `/* == Injected CSS from feature: ${feature.constructor.name} == */\n\n${feature.injectCSS()}\n`;
        }
      });

      // Inject it into the head so it's left alone
      $('head').append($('<style>', { id: 'toolkit-injected-styles', type: 'text/css' }).text(globalCSS));

      // Hook up listeners and then invoke any features that are ready to go.
      featureInstances.forEach(feature => {
        if (feature.settings.enabled) {
          feature.applyListeners();

          const willInvokeRetValue = feature.willInvoke();

          if (willInvokeRetValue && typeof willInvokeRetValue.then === 'function') {
            willInvokeRetValue.then(() => {
              if (feature.shouldInvoke()) {
                feature.invoke();
              }
            });
          } else {
            if (feature.shouldInvoke()) {
              feature.invoke();
            }
          }
        }
      });
    } else {
      setTimeout(poll, 250);
    }
  })();

  /***/
},
/* 16 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(2)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-toolkit-grid-cell-running-balance {\n\ttext-align: right;\n\twidth: 10%;\n}\n\n.ynab-toolkit-grid-cell-running-balance span.negative {\n\tcolor: #d33c2d;\n\tfont-weight: bold;\n}\n", ""]);

  // exports


  /***/
},
/* 17 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(2)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynabtk-stealing-from-next-month {\n\tcolor: red;\n}\n\n.ynabtk-month-link {\n\tcursor: pointer;\n\ttext-decoration: underline;\n}\n", ""]);

  // exports


  /***/
},
/* 18 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(2)(undefined);
  // imports


  // module
  exports.push([module.i, "div.referral-program {\n    display: none;\n}\n", ""]);

  // exports


  /***/
},
/* 19 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(16);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 20 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(17);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 21 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(18);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
}]);