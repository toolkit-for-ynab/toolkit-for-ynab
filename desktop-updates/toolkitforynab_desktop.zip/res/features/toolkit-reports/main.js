'use strict';

/* eslint-disable no-multi-str */

(function poll() {
  var allReportsReady = true;
  var supportedReports = [{
    name: 'Net Worth',
    toolkitId: 'netWorthReport'
  }, {
    name: 'Spending By Category',
    toolkitId: 'spendingByCategory'
  }, {
    name: 'Spending By Payee',
    toolkitId: 'spendingByPayee'
  }, {
    name: 'Income vs. Expense',
    toolkitId: 'incomeVsExpense'
  }];

  // ynabToolKit[report.toolkitId] should be undefined if the report hasn't finished
  // loading yet. if that's the case set allReportsReady to false to avoid silly race conditions
  supportedReports.forEach(function (report) {
    if (!ynabToolKit[report.toolkitId]) {
      allReportsReady = false;
    }
  });

  // if all the reports have finished loading (and so have their deps) then we're good to go!
  if (typeof ynabToolKit !== 'undefined' && ynabToolKit.actOnChangeInit === true && allReportsReady) {
    ynabToolKit.reports = function () {
      var onBudgetAccounts = void 0;
      var offBudgetAccounts = void 0;
      var allTransactions = void 0;
      var monthLabels = [];
      var selectedAccounts = [];

      // throw our reports button into the left-hand navigation pane so they can click it!
      function setUpReportsButton() {
        if ($('li.ynabtk-navlink-reports').length > 0) return;

        $('.nav-main > li:eq(1)').after($('<li>').append($('<li>', { class: 'ember-view ynabtk-navlink-reports' }).append($('<a>', { href: '#' }).append($('<span>', { class: 'ember-view flaticon stroke document-4' })).append(ynabToolKit.l10nData && ynabToolKit.l10nData['sidebar.reports'] || 'Toolkit Reports'))));

        $('.ynabtk-navlink-reports').on('click', showReports);
      }

      function buildReportsPage($pane) {
        if ($('.ynabtk-reports').length) return;

        updateNavigation();

        // append the entire page to the .scroll-wrap pane in YNAB (called by showReports)
        $pane.append($('<div class="ynabtk-reports"></div>')
        // append the navigation (list of supportedReports)
        .append(generateReportNavigation())
        // append the filters and containers for report headers/report data
        .append($('<div class="ynabtk-reports-filters"></div>').append('<h3>\n                    ' + (ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.filters'] || 'Filters') + '\n                  </h3>\n                  <div class="ynabtk-filter-group date-filter">\n                    <span class="reports-filter-name timeframe">\n                      ' + (ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.timeframe'] || 'Timeframe') + ':\n                    </span>\n                    <select class="ynabtk-filter-select ynabtk-quick-date-filters">\n                      <option value="none" disabled selected>Quick Filter...</option>\n                    </select>\n                    <div id="ynabtk-date-filter" class="ynabtk-date-filter-slider"></div>\n                  </div>\n                  <div class="ynabtk-filter-group">\n                    <span class="reports-filter-name">\n                      ' + (ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.accounts'] || 'Accounts') + ':\n                    </span>\n                    <select id="ynabtk-report-accounts" class="ynabtk-filter-select">\n                      <option value="all">All Budget Accounts</option>\n                    </select>\n                    <div id="selected-account-list" class="ynabtk-account-chips"></div>\n                  </div>')).append('<div class="ynabtk-reports-headers"></div>').append('<div class="ynabtk-reports-data"></div>'));

        generateDateSlider();
        generateQuickDateFilters();
      }

      function updateNavigation() {
        // remove the active class from all navigation items and add active to our guy
        $('.navlink-budget, .navlink-accounts').removeClass('active');
        $('.nav-account-row').removeClass('is-selected');
        $('.ynabtk-navlink-reports').addClass('active');

        $('.navlink-budget, .navlink-accounts, .nav-account-row').on('click', function () {
          // They're trying to navigate away.
          // Restore the highlight on whatever they're trying to click on.
          // For example, if they were on the Budget tab, then clicked on Reports, clicking on
          // Budget again wouldn't do anything as YNAB thinks they're already there. This switches
          // the correct classes back on and triggers our .observe below.
          if ($(this).hasClass('navlink-budget') || $(this).hasClass('navlink-accounts')) {
            $(this).addClass('active');
          } else if ($(this).hasClass('nav-account-row')) {
            $(this).addClass('is-selected');
          }
        });
      }

      function generateReportNavigation() {
        // create the reports header
        var $reportsHeader = $('<div class="ynabtk-reports-nav">\n            <h2>\n              <span><i class="flaticon stroke document-4"></i></span>\n            </h2>\n            <ul class="nav-reports"></ul>\n          </div>');

        // now populate the reports header!
        supportedReports.forEach(function (report) {
          $('.nav-reports', $reportsHeader).append($('<li>', { class: 'nav-reports-navlink' }).append($('<a>', { id: report.toolkitId, href: '#' }).text(report.name).click(function () {
            onReportSelected(report.toolkitId);
          })));
        });

        return $reportsHeader;
      }

      function generateDateSlider() {
        monthLabels = ynabToolKit.reports.generateMonthLabelsFromFirstTransaction(allTransactions);

        // if we only have one or no months of data that we should just hide the slider
        // return early so we don't even try to initialize the slider
        if (monthLabels.length < 2) {
          return $('.ynabtk-filter-group.date-filter').hide();
        }

        // default the start to the full range of dates, if there's a current-date-filter in localStorage
        // then make sure it's valid for our set of dates and use it.
        var start = [monthLabels[0], monthLabels[monthLabels.length - 1]];
        var storedStart = ynabToolKit.shared.getToolkitStorageKey('current-date-filter');
        if (storedStart && storedStart !== 'null' && storedStart !== 'undefined') {
          storedStart = storedStart.split(',');

          // they might have switched to a budget that doesn't have the dates in the stored value,
          // so make sure the values exist in our month labels. if they do, let it happen.
          if (storedStart.length === 2 && monthLabels.indexOf(storedStart[0]) !== -1 && monthLabels.indexOf(storedStart[1]) !== -1) {
            start = storedStart;
          }
        }

        var dateFilterContainer = document.getElementById('ynabtk-date-filter');
        noUiSlider.create(dateFilterContainer, {
          connect: true,
          start: start,
          range: {
            min: 0,
            max: monthLabels.length - 1
          },
          step: 1,
          tooltips: true,
          format: {
            to: function to(index) {
              return monthLabels[Math.round(index)];
            },
            from: function from(value) {
              return monthLabels.indexOf(value);
            }
          }
        });

        // on slide, set the new values in local storage and call filterTransactionsAndBuildChart!
        dateFilterContainer.noUiSlider.on('slide', function () {
          $('.ynabtk-quick-date-filters').val('none');

          var slideValue = dateFilterContainer.noUiSlider.get();
          ynabToolKit.shared.setToolkitStorageKey('current-date-filter', slideValue);
          filterTransactionsAndBuildChart();
        });
      }

      function generateQuickDateFilters() {
        var currentMonth = new Date().getMonth();
        var currentYear = new Date().getFullYear();
        var todayFormatted = ynabToolKit.reports.formatDatel8n(new Date(currentYear, currentMonth));
        var dateFilter = document.getElementById('ynabtk-date-filter');

        if (!dateFilter.noUiSlider) return;

        var quickFilters = [{
          name: 'This Month',
          filter: [todayFormatted, todayFormatted]
        }, {
          name: 'Last Month',
          filter: [ynabToolKit.reports.formatDatel8n(new Date(currentYear, currentMonth - 1)), ynabToolKit.reports.formatDatel8n(new Date(currentYear, currentMonth - 1))]
        }, {
          name: 'Latest Three Months',
          filter: [ynabToolKit.reports.formatDatel8n(new Date(currentYear, currentMonth - 2)), todayFormatted]
        }, {
          name: 'This Year',
          filter: [ynabToolKit.reports.formatDatel8n(new Date(currentYear, 0)), todayFormatted]
        }, {
          name: 'Last Year',
          filter: [ynabToolKit.reports.formatDatel8n(new Date(currentYear - 1, 0)), ynabToolKit.reports.formatDatel8n(new Date(currentYear - 1, 11))]
        }, {
          name: 'All Dates',
          filter: [monthLabels[0], monthLabels[monthLabels.length - 1]]
        }];

        quickFilters.forEach(function (quickFilter, index) {
          var disabled = false;
          // if we can't meet the end filter, then the button should be disabled
          if (monthLabels.indexOf(quickFilter.filter[1]) === -1) {
            disabled = true;
          } else if (monthLabels.indexOf(quickFilter.filter[0]) === -1) {
            // if we can't meet the start filter, just set the dates to the first available
            quickFilter[0] = monthLabels[0];
          }

          $('.ynabtk-quick-date-filters').append($('<option>', {
            value: index,
            disabled: disabled
          }).text(quickFilter.name));
        });

        $('.ynabtk-quick-date-filters').change(function () {
          var quickFilterIndex = parseInt($(this).val());
          var quickFilterValue = quickFilters[quickFilterIndex].filter;
          dateFilter.noUiSlider.set(quickFilterValue);
          ynabToolKit.shared.setToolkitStorageKey('current-date-filter', quickFilterValue);
          filterTransactionsAndBuildChart();
        });
      }

      function generateAccountSelect(availableAccountTypes) {
        var nonAccountOptions = ['all', 'onbudget', 'offbudget', 'custom'];

        // grab handles to the drop down and the list of selected accounts first
        var $select = $('#ynabtk-report-accounts');
        var $accountList = $('#selected-account-list');

        // clear both lists before generating the options
        $select.empty();
        $accountList.empty();

        $select.append('<option disabled value="custom">Select Specific Account...</option>');

        // based on the available account types for the report we're generating, add options
        // to the drop down. for 'all', add options to filter on on/off budget accounts as well
        switch (availableAccountTypes) {
          case 'onbudget':
            $select.append('<option value="onbudget">All Budget Accounts</option>');
            onBudgetAccounts.forEach(function (account) {
              $select.append($('<option>', { value: account.get('entityId'), text: account.get('accountName') }));
            });
            break;
          case 'offbudget':
            $select.append('<option value="offbudget">All Tracking Accounts</option>');
            offBudgetAccounts.forEach(function (account) {
              $select.append($('<option>', { value: account.get('entityId'), text: account.get('accountName') }));
            });
            break;
          case 'all':
          default:
            $select.append('<option value="all">All Accounts</option>');
            $select.append('<option value="onbudget">All Budget Accounts</option>');
            $select.append('<option value="offbudget">All Tracking Accounts</option>');
            onBudgetAccounts.concat(offBudgetAccounts).forEach(function (account) {
              $select.append($('<option>', { value: account.get('entityId'), text: account.get('accountName') }));
            });
            break;
        }

        // once the user changes the select find out if it's one of the "grouped" options (all/on/off) if it
        // is, then get rid of the selected accounts array, if it's not then add it to the selected accounts array
        $select.change(function () {
          if (nonAccountOptions.indexOf($select.val()) !== -1) {
            selectedAccounts = [];
          } else if (selectedAccounts.indexOf(this.value) === -1) {
            selectedAccounts.push(this.value);
          }

          updateAccountList();
          filterTransactionsAndBuildChart();
        });

        // this function updates the "chips" on the page every time the user changes the select
        function updateAccountList() {
          // remove them all first
          $accountList.empty();

          if (selectedAccounts.length === 0) {
            // if the selected accounts are empty and we didn't just click one of the "all" options
            // then go ahead and set the select to whatever our default for the report is.
            if (nonAccountOptions.indexOf($select.val()) === -1) {
              $select.val(availableAccountTypes);
            }
          } else {
            setTimeout(function () {
              $select.val('custom');
            }, 0);
          }

          // for each selected account, add a chip to the page when someone clicks the chip, it will get
          // removed from the list of chips. if they've clicked the last chip then the above code will default
          // us to whatever the default option of the report is
          selectedAccounts.forEach(function (accountId) {
            var accountData = onBudgetAccounts.find(function (account) {
              return accountId === account.get('entityId');
            }) || offBudgetAccounts.find(function (account) {
              return accountId === account.get('entityId');
            });
            $accountList.append($('<div>', {
              class: 'ynabtk-chip',
              title: accountData.get('accountName'),
              text: accountData.get('accountName')
            }).click(function () {
              var index = selectedAccounts.indexOf(accountId);
              selectedAccounts.splice(index, 1);
              updateAccountList();
              filterTransactionsAndBuildChart();
            }));
          });
        }

        updateAccountList();
      }

      function onReportSelected(toolkitId) {
        // change the current report in local storage so we can show it if they come back
        ynabToolKit.shared.setToolkitStorageKey('current-report', toolkitId);

        // grab the report, get any headers that the report may want to build
        var toolkitReport = ynabToolKit[toolkitId];
        $('.ynabtk-reports-headers').html(toolkitReport.reportHeaders());

        // update the report navigation to highlight the current active report
        $('.nav-reports .active').removeClass('active');
        $('#' + toolkitId, '.nav-reports').addClass('active');

        // generate the account filter options for our report
        generateAccountSelect(toolkitReport.availableAccountTypes);

        // finally, filter all the transactions for the report and call report.createChart()
        filterTransactionsAndBuildChart();
      }

      function filterTransaction(transaction, allowedDates, toolkitReport) {
        var filterType = void 0;

        // if the transaction isTombstone, or a scheduledTransaction then filter it out...
        if (transaction.get('isTombstone') || transaction.get('isScheduledTransaction')) {
          return false;
        }

        // should we filter for all, on, or off budget accounts?
        var transactionAccountId = transaction.get('accountId');
        if (selectedAccounts.length === 0) {
          var $accountSelect = $('#ynabtk-report-accounts');
          filterType = $accountSelect.val();
        }

        // filter based on account type
        switch (filterType) {
          case 'onbudget':
            if (!onBudgetAccounts.find(function (account) {
              return transactionAccountId === account.get('entityId');
            })) {
              return false;
            }
            break;
          case 'offbudget':
            if (!offBudgetAccounts.find(function (account) {
              return transactionAccountId === account.get('entityId');
            })) {
              return false;
            }
            break;
          case 'all':
            // no filtering needed -- continue
            break;
          default:
            // specific accounts selected.
            if (selectedAccounts.indexOf(transactionAccountId) === -1) {
              return false;
            }
            break;
        }

        // make sure the transaction date is in the slice of the above array
        if (!toolkitReport.ignoreDateFilter) {
          var transactionDate = ynabToolKit.reports.formatTransactionDatel8n(transaction);
          if (allowedDates.indexOf(transactionDate) === -1) {
            return false;
          }
        }

        // now that we've filtered by account and date, make sure there's no extra filtering required
        // by our report. if there is, return the value of that function, otherwise, return true, she's a keeper!
        if (toolkitReport.filterTransaction) {
          return toolkitReport.filterTransaction(transaction);
        }

        return true;
      }

      function filterTransactionsAndBuildChart() {
        // grab the toolkitReport based of the current-report in local storage
        var toolkitId = ynabToolKit.shared.getToolkitStorageKey('current-report');
        var toolkitReport = ynabToolKit[toolkitId];

        // default our date filter to all dates int the monthLabels array
        var indexStart = 0;
        var indexEnd = monthLabels.length;

        // grab the slider from the page, if it's initialized then make sure we get the current
        // dates set by the user. if it's not then our above default will suffice
        var sliderElement = document.getElementById('ynabtk-date-filter');
        if (sliderElement.noUiSlider && typeof sliderElement.noUiSlider.get === 'function') {
          // noUiSlider.get() returns the string representations of the items in the labels, so grab the
          // index of those elements afterwards. add one to the index end of self-explanatory array indexing reasons
          var dateFilterRange = document.getElementById('ynabtk-date-filter').noUiSlider.get();
          indexStart = monthLabels.indexOf(dateFilterRange[0]);
          indexEnd = monthLabels.indexOf(dateFilterRange[1]) + 1;
        }

        // now that we have a start and end index, we know what slice of the array to take
        ynabToolKit.reports.allowedDateStart = indexStart;
        ynabToolKit.reports.allowedDateEnd = indexEnd;
        var allowedDates = monthLabels.slice(indexStart, indexEnd);

        // filter out the transactions
        var filtered = allTransactions.filter(function (transaction) {
          return filterTransaction(transaction, allowedDates, toolkitReport);
        });

        // call calculate. all reports should return us a promise for calculate just in case
        // they need to grab all categories or some item that's returned to us through a promise.
        toolkitReport.calculate(filtered).then(function () {
          // send the ynabtk-reports-data container into createChart so it knows where to build the data
          toolkitReport.createChart($('.ynabtk-reports-data'));
        });
      }

      function showReports() {
        // If we're not on the budget tab, then we need to be for the drill down detail
        // dialog to work. Go ahead and ask to be there.
        var router = ynabToolKit.shared.containerLookup('router:main');

        if (router.currentRouteName !== 'budget.select') {
          $('.navlink-budget a').click();
        }

        // grab all the transactions...
        ynab.YNABSharedLib.getBudgetViewModel_AllAccountTransactionsViewModel().then(function (transactionsViewModel) {
          // then grab the sidebar so we can get all the accounts...
          ynab.YNABSharedLib.getBudgetViewModel_SidebarViewModel().then(function (sideBarViewModel) {
            // store the accounts/transactions off on their own variables so we can use them later
            var closedAccounts = sideBarViewModel.get('closedAccounts');
            onBudgetAccounts = sideBarViewModel.get('onBudgetAccounts').concat(closedAccounts.filter(function (account) {
              return account.get('onBudget');
            }));
            offBudgetAccounts = sideBarViewModel.get('offBudgetAccounts').concat(closedAccounts.filter(function (account) {
              return !account.get('onBudget');
            }));
            allTransactions = transactionsViewModel.get('visibleTransactionDisplayItems');

            // sort the transactions by date. They usually are already, but let's not depend on that:
            allTransactions.sort(function (a, b) {
              return a.get('date').toNativeDate() - b.get('date').toNativeDate();
            });

            // clear out the content and put ours in there instead.
            buildReportsPage($('div.scroll-wrap').closest('.ember-view'));

            // The budget header is absolute positioned
            $('.budget-header, .scroll-wrap').hide();

            // grab the value of the current-report inside localStorage
            var storedCurrentReport = ynabToolKit.shared.getToolkitStorageKey('current-report');

            // make sure whatever it is is actually a supported report (might be 'null' or 'undefined') because
            // string storage of values is a cool thing, ya know?
            var currentReport = supportedReports.find(function (report) {
              return report.toolkitId === storedCurrentReport;
            });

            // if it's a valid report, then go ahead and show it, if it's not then show the first available report
            if (currentReport) {
              onReportSelected(currentReport.toolkitId);
            } else {
              onReportSelected(supportedReports[0].toolkitId);
            }
          });
        });
      }

      return {
        invoke: function invoke() {
          setUpReportsButton();
        },
        observe: function observe(changedNodes) {
          // Did they switch budgets?
          if (changedNodes.has('layout user-logged-in')) {
            if ($('.nav-main').length) {
              ynabToolKit.reports.invoke();
            }
          }

          // Did they switch away from our tab?
          if (changedNodes.has('navlink-budget active') || changedNodes.has('navlink-accounts active') || changedNodes.has('navlink-reports active') || changedNodes.has('active navlink-reports') || changedNodes.has('nav-account-row is-selected')) {
            // The user has left the reports page.
            // We're no longer the active page.
            $('.ynabtk-navlink-reports').removeClass('active');

            $('.ynabtk-reports').remove();

            // And restore the YNAB stuff we hid earlier
            $('.budget-header, .scroll-wrap').show();
          }

          // if YNAB overwrites the sidebar-contents just make sure the report button
          // doesn't get deleted
          if (changedNodes.has('sidebar-contents')) {
            setUpReportsButton();
          }
        },
        formatTransactionDatel8n: function formatTransactionDatel8n(transaction) {
          var nativeDate = transaction.get('date').toNativeDate();
          return this.formatDatel8n(nativeDate);
        },
        formatDatel8n: function formatDatel8n(date) {
          var formattedDate = ynab.YNABSharedLib.dateFormatter.formatDate(date, 'MMM YYYY');

          // now split it with year and month so that we can get the localized version of the month
          var year = formattedDate.split(' ')[1];
          var month = formattedDate.split(' ')[0];
          month = ynabToolKit.l10nData && ynabToolKit.l10nData['months.' + month] || month;
          formattedDate = month + ' ' + year;

          // finally, return the l8n date.
          return formattedDate;
        },
        generateMonthLabelsFromFirstTransaction: function generateMonthLabelsFromFirstTransaction(transactions, endWithLastTransaction) {
          var monthLabelsForTransaction = [];
          // grab the current month, this is the last label of our slider
          var endMonth = new Date().getMonth();
          var endYear = new Date().getFullYear();

          if (endWithLastTransaction) {
            var lastTransaction = void 0;
            for (var i = transactions.length - 1; i >= 0; i--) {
              lastTransaction = transactions[i];
              if (!lastTransaction.get('isTombstone') && !lastTransaction.get('isScheduledTransaction')) break;
            }

            var lastTransactionDate = lastTransaction ? lastTransaction.get('date') : undefined;
            endMonth = lastTransactionDate ? lastTransactionDate.getMonth() : endMonth;
            endYear = lastTransactionDate ? lastTransactionDate.getYear() : endYear;
          }

          // find the first non-tombstoned, non scheduled transaction.
          var firstTransaction = transactions.find(function (transaction) {
            return !transaction.get('isTombstone') && !transaction.get('isScheduledTransaction');
          });

          // grab the date from that transaction
          var firstTransactionDate = firstTransaction ? firstTransaction.get('date') : undefined;
          var currentLabelMonth = firstTransactionDate ? firstTransactionDate.getMonth() : endMonth;
          var currentLabelYear = firstTransactionDate ? firstTransactionDate.getYear() : endYear;

          // start with the month/year on the very first transaction, we should create the labels needed
          // for our slider until the current month/year. use a while loop to do this because there's no need
          // to loop over every transaction. we get the current and end values from date objects which are
          // all 0-indexed but when this loop runs, we increment currentMonth at the very end which means
          // we're going to need to check currentLabelMonth - 1 in our while condition. this isn't a bad thing
          // because it means we'll also always insert our last month in the while loop and there's no need for
          // extra lines of code after. just extra lines of comments before :D
          while (!(currentLabelYear === endYear && currentLabelMonth - 1 === endMonth)) {
            if (currentLabelMonth === 12) {
              currentLabelMonth = 0;
              currentLabelYear++;
            }

            var labelDate = new Date(currentLabelYear, currentLabelMonth);
            var labelDateFormatted = ynabToolKit.reports.formatDatel8n(labelDate);
            monthLabelsForTransaction.push(labelDateFormatted);

            currentLabelMonth++;
          }

          return monthLabelsForTransaction;
        }
      };
    }();

    ynabToolKit.reports.invoke();
  } else {
    setTimeout(poll, 250);
  }
})();