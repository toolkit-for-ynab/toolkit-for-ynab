'use strict';

(function poll() {
  if (typeof ynabToolKit !== 'undefined' && ynabToolKit.actOnChangeInit === true) {
    ynabToolKit.toggleSplits = function () {
      var isToggling = false;
      var accountsController = ynabToolKit.shared.containerLookup('controller:accounts');
      accountsController.reopen({
        toolkitShowSubTransactions: false,
        contentResults: Ember.computed({
          get: function get() {
            return [];
          },
          set: function set(key, val) {
            if (!this.get('toolkitShowSubTransactions')) {
              val = val.filter(function (transaction) {
                var displayItemType = transaction.get('displayItemType');
                return displayItemType !== ynab.constants.TransactionDisplayItemType.SubTransaction && displayItemType !== ynab.constants.TransactionDisplayItemType.ScheduledSubTransaction;
              });
            }
            return val;
          }
        })
      });

      function hideSubTransactions() {
        isToggling = true;
        ynabToolKit.toggleSplits.setting = 'hide';
        accountsController.set('toolkitShowSubTransactions', false);
        Ember.run.debounce(accountsController, accountsController._filterContent, 25);
      }

      function showSubTransactions() {
        isToggling = true;
        ynabToolKit.toggleSplits.setting = 'show';
        accountsController.set('toolkitShowSubTransactions', true);
        Ember.run.debounce(accountsController, accountsController._filterContent, 25);
      }

      return {
        setting: 'init',
        invoke: function invoke() {
          if (!$('#toggle-splits').length) {
            var buttonText = ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.toggleSplits'] || 'Toggle Splits';

            $('<button>', { id: 'toggle-splits', class: 'ember-view button' }).append($('<i>', { class: 'ember-view flaticon stroke right' })).append($('<i>', { class: 'ember-view flaticon stroke down' })).append(' ' + buttonText).insertAfter('.accounts-toolbar .undo-redo-container');

            $('.accounts-toolbar-left').find('#toggle-splits').click(function () {
              if (ynabToolKit.toggleSplits.setting === 'hide') {
                showSubTransactions();
              } else {
                hideSubTransactions();
              }

              $('#toggle-splits > i').toggle();
            });
          }

          // default the right arrow to hidden
          if (ynabToolKit.toggleSplits.setting === 'init' || ynabToolKit.toggleSplits.setting === 'hide') {
            $('#toggle-splits > .down').hide();
            hideSubTransactions();
          } else {
            $('#toggle-splits > .right').hide();
            showSubTransactions();
          }
        },

        observe: function observe(changedNodes) {
          if (changedNodes.has('ynab-grid-body') && !isToggling) {
            ynabToolKit.toggleSplits.invoke();
          }
        },

        onRouteChanged: function onRouteChanged(changedRoute) {
          if (changedRoute.indexOf('accounts') > -1) {
            ynabToolKit.toggleSplits.invoke();
          }
        }
      };
    }();

    var router = ynabToolKit.shared.containerLookup('router:main');
    if (router.get('currentPath').indexOf('accounts') > -1) {
      ynabToolKit.toggleSplits.invoke();
    }
  } else {
    setTimeout(poll, 250);
  }
})();