'use strict';

(function poll() {
  if (typeof ynabToolKit !== 'undefined' && ynabToolKit.actOnChangeInit === true) {
    ynabToolKit.popupCalculator = function () {
      var popupCalc = new Calculator();
      var $field = '';
      var btnRight = 0;
      var btnBottom = -242;
      var afterElement = '';
      var appendElement = '';
      var deleteOnDismiss = false;
      var origValue = '';
      var popupButton = 'toolkit-popup-calc-button';
      var calcValue = 0;
      var setValueCallback = '';
      var getValueCallback = '';
      var decimalDigits = ynab.YNABSharedLib.currencyFormatter.getCurrency().decimal_digits;
      var decimalSeparator = ynab.YNABSharedLib.currencyFormatter.getCurrency().decimal_separator;
      var separatorCode = decimalSeparator.charCodeAt(0);

      return {
        setDeleteOnDismiss: function setDeleteOnDismiss(val) {
          deleteOnDismiss = val;

          return;
        },
        setInsertAfterElement: function setInsertAfterElement(val) {
          afterElement = val;
          appendElement = '';

          return;
        },
        setAppendToElement: function setAppendToElement(val) {
          appendElement = val;
          afterElement = '';

          return;
        },
        setButtonRight: function setButtonRight(val) {
          btnRight = val;

          return;
        },
        setButtonBottom: function setButtonBottom(val) {
          btnBottom = val;

          return;
        },
        setPopupButton: function setPopupButton(val) {
          popupButton = val;

          return;
        },
        setEntryField: function setEntryField(val) {
          $field = val;

          return;
        },
        getEntryField: function getEntryField() {
          return $field;
        },
        setSetValueCallback: function setSetValueCallback(callback) {
          setValueCallback = callback;
        },
        setGetValueCallback: function setGetValueCallback(callback) {
          getValueCallback = callback;
        },
        showCalculator: function showCalculator(budgetScreen) {
          $('#' + popupButton).prop('disabled', true);

          popupCalc.reset();

          origValue = getValueCallback($field);

          if (origValue === '') {
            origValue = '0' + decimalSeparator + '0'.repeat(decimalDigits);
          }

          popupCalc.value(origValue);

          if ($('#toolkitPopupCalc').length) {
            $('#toolkitPopupCalcInput').val(origValue);
            $('#toolkitPopupCalc').removeClass('toolkit-popup-calc-hide');
          } else {
            var actionsClass = budgetScreen ? 'ynab-grid-actions' : 'toolkit-calc-actions';
            var $calc = $('<div>', { id: 'toolkitPopupCalc', class: 'ember-view ' + actionsClass, style: 'right: ' + btnRight + 'px; bottom: ' + btnBottom + 'px;' }).append($('<input>', { id: 'toolkitPopupCalcInput', readonly: 'readonly', class: 'ember-view ember-text-field' }).val(origValue)).append($('<ul>', { class: 'toolkit-popup-calc-btnrow' }).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnC', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('C').click(function () {
              doCalculation('C');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnN', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('+/-').click(function () {
              doCalculation('N');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnB', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('<-').click(function () {
              doCalculation('Delete');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnD', class: 'ember-view button button-primary toolkit-popup-calc-button1 toolkit-popup-calc-btncol4' }).append('/').click(function () {
              doCalculation('/');
            })))).append($('<ul>', { class: 'toolkit-popup-calc-btnrow' }).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn7', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('7').click(function () {
              doCalculation('7');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn8', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('8').click(function () {
              doCalculation('8');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn9', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('9').click(function () {
              doCalculation('9');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnM', class: 'ember-view button button-primary toolkit-popup-calc-button1 toolkit-popup-calc-btncol4' }).append('X').click(function () {
              doCalculation('*');
            })))).append($('<ul>', { class: 'toolkit-popup-calc-btnrow' }).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn4', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('4').click(function () {
              doCalculation('4');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn5', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('5').click(function () {
              doCalculation('5');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn6', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('6').click(function () {
              doCalculation('6');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnS', class: 'ember-view button button-primary toolkit-popup-calc-button1 toolkit-popup-calc-btncol4' }).append('-').click(function () {
              doCalculation('-');
            })))).append($('<ul>', { class: 'toolkit-popup-calc-btnrow' }).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn1', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('1').click(function () {
              doCalculation('1');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn2', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('2').click(function () {
              doCalculation('2');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn3', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('3').click(function () {
              doCalculation('3');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnA', class: 'ember-view button button-primary toolkit-popup-calc-button1 toolkit-popup-calc-btncol4' }).append('+').click(function () {
              doCalculation('+');
            })))).append($('<ul>', { class: 'toolkit-popup-calc-btnrow' }).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn0', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('0').click(function () {
              doCalculation('0');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnP', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('.').click(function () {
              doCalculation('.');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtnE', class: 'ember-view button button-primary toolkit-popup-calc-button1' }).append('=').click(function () {
              doCalculation('=');
            }))).append($('<li>', { class: 'toolkit-popup-calc-btnrow' }).append($('<button>', { id: 'toolkitBtn%', class: 'ember-view button button-primary toolkit-popup-calc-button1 toolkit-popup-calc-btncol4' }).append('%').click(function () {
              doCalculation('%');
            })))).append($('<button>', { id: 'toolkitBtnOk', class: 'ember-view button button-primary toolkit-popup-calc-button2' }).append('OK').click(function () {
              doCalculation('OK');
              dismissCalculator();
            })).append($('<button>', { id: 'toolkitBtnCan', class: 'ember-view button button-primary toolkit-popup-calc-button2' }).append('Cancel').click(function () {
              dismissCalculator();
            }));

            if (afterElement !== '') {
              $calc.insertAfter(afterElement);
            } else {
              $calc.appendTo(appendElement);
            }
          }

          $(document).on('keyup.toolkitPopupCalc', function (e) {
            if (e.which === 27) {
              // ESC key?
              dismissCalculator();
            } else if (e.which > 45 && e.which < 58 || // keyboard
            e.which > 95 && e.which < 112 || // numpad
            e.which === separatorCode || // keyboard period (190) or comma (188) or ???
            e.which === 187 || // keyboard plus (shift key plus equal key)
            e.which === 189 || // keyboard minus
            e.which === 191 || // keyboard forward slash (divide)
            e.which === 8 || // backspace
            e.which === 13) {
              // numpad enter
              doCalculation(e.key);

              if (e.which === 13 || e.which === 18) {
                // Enter key?
                dismissCalculator();
              }
            }
          });

          // Handle mouse clicks outside the drop-down modal. Namespace the
          // click event so we can remove our specific instance.
          $(document).on('click.toolkitPopupCalc', function (e) {
            if (e.target.id !== 'toolkitPopupCalc') {
              dismissCalculator();
            }
          });

          function dismissCalculator() {
            if (deleteOnDismiss) {
              $('#toolkitPopupCalc').remove();
            } else {
              $('#toolkitPopupCalc').addClass('toolkit-popup-calc-hide');
            }

            $('#' + popupButton).removeClass('toolkit-popup-calc-button-hide');
            $('#' + popupButton).prop('disabled', false);

            $(document).off('click.toolkitPopupCalc');
            $(document).off('keyup.toolkitPopupCalc');

            calcValue = '';
          }
        }
      };

      function Calculator() {
        var _oper = '';
        var result = '';
        var reveal = false;
        var _format = false;
        var value1 = '';
        var value2 = '';

        return {
          input: function input(key) {
            reveal = true;
            _format = false;

            if (result === '0' || result === ynab.YNABSharedLib.currencyFormatter.format(ynab.YNABSharedLib.currencyFormatter.convertToMilliDollars(result))) {
              result = '';
            }

            if (value2.toString().includes(decimalSeparator) && key === decimalSeparator) {
              key = '';
            }

            result = value2 + key + ''; // ensure concatenation
            value2 = result; // set potential second value
            return result;
          },
          eval: function _eval() {
            if (value2 === '') {
              reveal = false;
              _format = false;
            } else {
              if (decimalSeparator !== '.') {
                value2 = ynab.YNABSharedLib.defaultInstance.currencyFormatter.unformat(value2);
              }

              switch (_oper) {
                case '+':
                  result = parseFloat(value1) + parseFloat(value2);
                  break;
                case '-':
                  result = parseFloat(value1) - parseFloat(value2);
                  break;
                case '/':
                  result = parseFloat(value1) / parseFloat(value2);
                  break;
                case '*':
                  result = parseFloat(value1) * parseFloat(value2);
                  break;
                case '%':
                  result = parseFloat(value1) * parseFloat('.' + value2);
                  break;
              }

              value1 = result;
              value2 = '';
              _oper = '';
              reveal = true;
              _format = true;
            }

            return result;
          },
          clear: function clear() {
            _oper = '';
            value1 = '';
            value2 = '';
            result = ynab.YNABSharedLib.currencyFormatter.format(ynab.YNABSharedLib.currencyFormatter.convertToMilliDollars(0));
            reveal = true;
            _format = true;

            return result;
          },
          negate: function negate() {
            _oper = '*';
            value2 = '-1';

            return this.eval();
          },
          percent: function percent() {
            reveal = true;
            _format = true;
            value2 = parseFloat(value1) * parseFloat(value2 / 100);

            return value2;
          },
          oper: function oper(key) {
            if (key === '=') {
              _oper = '';
              _format = true;
            } else {
              _oper = key;
              _format = false;
            }
          },
          value: function value(key) {
            value1 = ynab.YNABSharedLib.defaultInstance.currencyFormatter.unformat(key);
            result = value1;
          },
          display: function display() {
            return reveal;
          },
          format: function format() {
            return _format;
          },
          backspace: function backspace() {
            if (value1.length > 0) {
              value1 = value1.slice(0, value1.length - 1);
            }
            value2 = '';
            result = '';
            _format = false;
            reveal = true;
            return value1;
          },
          reset: function reset() {
            _oper = '';
            result = '';
            value1 = '';
            value2 = '';
            calcValue = '';
          }
        };
      }

      function doCalculation(calcVerb) {
        switch (calcVerb) {
          case 'Enter': // keypad <enter>
          case 'OK':
            // button OK
            calcValue = popupCalc.eval();

            setValueCallback($field, ynab.YNABSharedLib.currencyFormatter.format(ynab.YNABSharedLib.currencyFormatter.convertToMilliDollars(calcValue)));
            break;
          case 'Delete': // button <-
          case 'Backspace':
            // keyboard <-
            calcValue = popupCalc.backspace();

            break;
          case 'C':
            // button C
            calcValue = popupCalc.clear();

            break;
          case 'N':
            // button +/-
            calcValue = popupCalc.negate();

            break;
          case '=': // keyboard =
          case '+': // keypad/button +
          case '-': // keypad/button -
          case '/': // keypad/button /
          case '*':
            // keypad/button *
            calcValue = popupCalc.eval(); // evaluate existing expression
            popupCalc.oper(calcVerb); // set operator for next evaluation

            break;
          case '%':
            // keyboard %
            calcValue = popupCalc.percent(); // evaluate existing expression

            break;
          default:
            calcValue = popupCalc.input(calcVerb);
        }

        if (popupCalc.display()) {
          if (popupCalc.format()) {
            $('#toolkitPopupCalcInput').val(ynab.YNABSharedLib.currencyFormatter.format(ynab.YNABSharedLib.currencyFormatter.convertToMilliDollars(calcValue)));
          } else {
            $('#toolkitPopupCalcInput').val(calcValue);
          }
        }

        event.stopPropagation();
      }
    }();
  } else {
    setTimeout(poll, 250);
  }
})();