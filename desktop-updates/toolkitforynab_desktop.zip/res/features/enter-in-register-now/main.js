'use strict';

(function poll() {
  if (typeof ynabToolKit !== 'undefined' && ynabToolKit.actOnChangeInit === true) {
    ynabToolKit.enterInRegisterNow = function () {
      var accountsController = void 0;
      var transactionViewModel = void 0;

      // this function was taken pretty much verbatim from YNAB source code
      // they have a function called generateUpcomingTransactionNow which takes
      // a list of entity ids to generate.
      function enterTransactionInRegisterNow(transactionsToEnter) {
        var entityManger = transactionViewModel.getEntityManager();
        entityManger.openChangeSet();

        var transactionIds = transactionsToEnter.map(function (t) {
          return t.get('entityId');
        });

        try {
          transactionViewModel.getYNABDatabase().generateUpcomingTransactionNow(transactionIds).then(function () {
            entityManger.closeChangeSet();
            accountsController.send('closeModal');
          });
        } catch (e) {
          accountsController.send('closeModal');
          ynabToolKit.shared.showFeatureErrorModal('Enter In Register Now');
        }
      }

      function addOptionToContextMenu() {
        var selectedTransactions = accountsController.get('areChecked');
        var canEnterNow = selectedTransactions.every(function (t) {
          return t.get('isScheduledTransaction');
        });

        if (!canEnterNow) return;

        $('.modal-account-edit-transaction-list .modal-list').prepend($('<li>\n                <button class="button-list ynab-toolkit-enter-in-register-now">\n                  <i class="flaticon stroke share-2"></i>\n                  Enter In Register Now\n                </button>\n              </li>').click(function () {
          enterTransactionInRegisterNow(selectedTransactions);
        }));
      }

      return {
        invoke: function invoke() {
          if (window.YNABFEATURES['enter-scheduled-transaction-now']) {
            return;
          }

          accountsController = ynabToolKit.shared.containerLookup('controller:accounts');
          transactionViewModel = accountsController.get('transactionViewModel');
          addOptionToContextMenu();
        },
        observe: function observe(changedNodes) {
          if (changedNodes.has('ynab-u modal-popup\nmodal-account-edit-transaction-list ember-view modal-overlay active')) {
            ynabToolKit.enterInRegisterNow.invoke();
          }
        }
      };
    }();

    ynabToolKit.enterInRegisterNow.invoke();
  } else {
    setTimeout(poll, 250);
  }
})();