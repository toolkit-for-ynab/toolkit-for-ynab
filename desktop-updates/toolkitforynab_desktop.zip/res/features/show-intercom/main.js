'use strict';

(function poll() {
  // Waits until an external function gives us the all clear that we can run (at /shared/main.js)
  if (typeof ynabToolKit !== 'undefined' && ynabToolKit.pageReady === true) {
    ynabToolKit.showIntercom = function () {
      return {
        invoke: function invoke() {
          var $modal = $('.modal-user-prefs .modal');
          var $modalList = $('.modal-user-prefs .modal-list');

          if ($('.ynab-toolkit-show-intercom', $modalList).length) return;

          $('<li class="ynab-toolkit-show-intercom">\n              <button>\n                <i class="flaticon stroke warning-2"></i>\n                Show Intercom\n              </button>\n             </li>\n          ').click(function () {
            var accountController = ynabToolKit.shared.containerLookup('controller:accounts');
            Intercom('show'); // eslint-disable-line new-cap
            accountController.send('closeModal');
          }).appendTo($modalList);

          $modal.css({ height: '+=12px' });
        },
        observe: function observe(changedNodes) {
          if (changedNodes.has('ynab-u modal-popup modal-user-prefs ember-view modal-overlay active')) {
            ynabToolKit.showIntercom.invoke();
          }
        }
      };
    }(); // Keep feature functions contained within this object
  } else {
    setTimeout(poll, 250);
  }
})();