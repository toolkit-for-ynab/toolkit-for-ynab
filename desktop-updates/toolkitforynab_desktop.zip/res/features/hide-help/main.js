'use strict';

(function poll() {
  // Waits until an external function gives us the all clear that we can run (at /shared/main.js)
  if (typeof ynabToolKit !== 'undefined' && ynabToolKit.pageReady === true) {
    ynabToolKit.hideHelp = function () {
      return {
        hideHelp: 'true',

        invoke: function invoke() {
          var hideHelp = ynabToolKit.shared.getToolkitStorageKey('hide-help');

          if (hideHelp === null) {
            ynabToolKit.shared.setToolkitStorageKey('hide-help', 'true');
            hideHelp = 'true';
          }

          if (hideHelp === 'true') {
            $('body').addClass('toolkit-hide-help');
          }
        },
        observe: function observe(changedNodes) {
          if (changedNodes.has('ynab-u modal-popup modal-user-prefs ember-view modal-overlay active')) {
            ynabToolKit.hideHelp.updatePopup();
          }
        },
        updatePopup: function updatePopup() {
          var $modal = $('.modal-user-prefs .modal');
          var $modalList = $('.modal-user-prefs .modal-list');

          if ($('.ynab-toolkit-hide-help', $modalList).length) return;

          var $label = 'Show';
          if ($('#hs-beacon').is(':visible')) {
            $label = 'Hide';
          }

          $('<li class="ynab-toolkit-hide-help">\n            <button>\n              <i class="flaticon stroke help-2"></i>\n              ' + $label + ' Help Button\n            </button>\n           </li>\n          ').click(function () {
            ynabToolKit.hideHelp.hideHelp = !ynabToolKit.hideHelp.hideHelp;
            ynabToolKit.shared.setToolkitStorageKey('hide-help', ynabToolKit.hideHelp.hideHelp);
            $('body').toggleClass('toolkit-hide-help');
            var accountController = ynabToolKit.shared.containerLookup('controller:accounts');
            accountController.send('closeModal');
          }).appendTo($modalList);

          $modal.css({ height: '+=12px' });
        }
      };
    }(); // Keep feature functions contained within this object

    ynabToolKit.hideHelp.invoke();
  } else {
    setTimeout(poll, 250);
  }
})();